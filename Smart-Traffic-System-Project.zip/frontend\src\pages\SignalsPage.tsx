import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  Radio,
  Zap,
  Sliders,
  ShieldAlert,
  ArrowRight,
  TrendingDown,
  Clock,
  RotateCcw,
  CheckCircle,
  AlertTriangle,
  Flame,
  Info,
} from 'lucide-react';
import { Direction, SignalColor } from '../types/traffic';
import { getNextDirection } from '../services/adaptiveSignalService';

export const SignalsPage: React.FC = () => {
  const {
    intersections,
    selectedIntersectionId,
    setSelectedIntersectionId,
    runOptimization,
    setManualOverride,
    logs,
  } = useTraffic();

  const selectedIntersection =
    intersections.find((i) => i.id === selectedIntersectionId) || intersections[0];

  const [overrideDir, setOverrideDir] = useState<Direction>('NORTH');
  const [overrideCol, setOverrideCol] = useState<SignalColor>('GREEN');

  if (!selectedIntersection) return null;

  const signal = selectedIntersection.signal;
  const isGreen = signal.color === 'GREEN';
  const isYellow = signal.color === 'YELLOW';
  const isRed = signal.color === 'RED';
  const nextDir = getNextDirection(signal.activeDirection);

  const intersectionLogs = logs.filter((l) => l.intersectionId === selectedIntersection.id);
  const latestLog = intersectionLogs[0];

  const handleApplyOverride = () => {
    setManualOverride(selectedIntersection.id, overrideDir, overrideCol, true);
  };

  const handleDisableOverride = () => {
    setManualOverride(selectedIntersection.id, 'NORTH', 'GREEN', false);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header & Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Adaptive Traffic Signal Management
            <span className="text-xs font-mono font-normal text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
              Demand-Responsive Algorithm
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Dynamic phase split allocation based on queue backlogs, with fail-safe interlocks and manual supervisor override.
          </p>
        </div>

        {/* Junction Switcher */}
        <div className="flex items-center gap-2">
          <label className="text-xs text-slate-400 font-mono">Select Node:</label>
          <select
            value={selectedIntersection.id}
            onChange={(e) => setSelectedIntersectionId(e.target.value)}
            className="bg-[#131D31] border border-slate-700 text-xs font-medium text-white rounded-xl px-3 py-2 focus:outline-none focus:border-blue-500"
          >
            {intersections.map((item) => (
              <option key={item.id} value={item.id}>
                {item.name} ({item.id})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Manual Override Active Warning */}
      {signal.isManualOverride && (
        <div className="p-4 rounded-xl bg-purple-950/60 border border-purple-500/40 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-purple-400 animate-ping" />
            <div>
              <div className="text-xs font-bold text-purple-200 uppercase tracking-wider">
                Manual Override Engaged by Traffic Administrator
              </div>
              <p className="text-xs text-purple-300/80">
                Automated cyclic timing is paused. Direction <strong>{signal.activeDirection}</strong> is forced to <strong>{signal.color}</strong>. Safety interlocks prevent conflicting greens.
              </p>
            </div>
          </div>
          <button
            onClick={handleDisableOverride}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white transition"
          >
            Restore Automated Cyclic Timing
          </button>
        </div>
      )}

      {/* Main Grid: Visual 4-Way Crossroad & Controller Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual 4-Way Junction Display (7 cols) */}
        <div className="lg:col-span-7 bg-[#131D31] border border-slate-800/90 rounded-2xl p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <Radio className="w-4 h-4 text-emerald-400" />
                Physical Phase Simulator: {selectedIntersection.name}
              </h3>
              <p className="text-xs text-slate-400 font-mono mt-0.5">
                Cycle Total: {signal.cycleTotalSec}s &bull; Mode: {signal.isManualOverride ? 'MANUAL' : 'DYNAMIC ADAPTIVE'}
              </p>
            </div>
            <span
              className={`px-2.5 py-1 rounded-full text-[11px] font-mono font-bold ${
                isGreen
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : isYellow
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-red-500/20 text-red-400 border border-red-500/30'
              }`}
            >
              {signal.color} PHASE ({signal.timeRemainingSec}s)
            </span>
          </div>

          {/* Visual 4-Way Crossroad Schematic */}
          <div className="relative w-full h-[380px] bg-slate-950 rounded-2xl border border-slate-800 flex items-center justify-center overflow-hidden my-2">
            {/* Road Crosshair Background */}
            {/* Vertical Road */}
            <div className="absolute w-28 h-full bg-slate-900 border-x border-dashed border-slate-700/60 flex flex-col justify-between items-center py-2">
              <div className="w-0.5 h-12 bg-amber-400/80 mb-2" />
              <div className="w-0.5 h-12 bg-amber-400/80 mt-2" />
            </div>
            {/* Horizontal Road */}
            <div className="absolute h-28 w-full bg-slate-900 border-y border-dashed border-slate-700/60 flex justify-between items-center px-2">
              <div className="h-0.5 w-12 bg-amber-400/80 mr-2" />
              <div className="h-0.5 w-12 bg-amber-400/80 ml-2" />
            </div>

            {/* Central Junction Hub */}
            <div className="relative z-10 w-28 h-28 bg-slate-800/80 border border-blue-500/30 rounded-xl flex flex-col items-center justify-center p-2 text-center backdrop-blur shadow-2xl">
              <div className="text-[10px] uppercase font-mono text-slate-400">Phase Active</div>
              <div className="text-xs font-bold text-white font-mono mt-0.5">
                {signal.activeDirection}
              </div>
              <div
                className={`text-2xl font-black font-mono mt-0.5 ${
                  isGreen ? 'text-emerald-400' : isYellow ? 'text-amber-400' : 'text-red-400'
                }`}
              >
                {signal.timeRemainingSec}s
              </div>
            </div>

            {/* NORTH Approach Signal & Queue */}
            <div className="absolute top-3 flex flex-col items-center z-20">
              <div
                className={`p-2 rounded-xl border flex items-center gap-2 ${
                  signal.activeDirection === 'NORTH'
                    ? 'bg-slate-900/95 border-emerald-500/80 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col gap-1 items-center bg-black/80 p-1 rounded border border-slate-700">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'NORTH' && signal.color === 'RED'
                        ? 'bg-red-500 shadow-sm shadow-red-500'
                        : 'bg-red-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'NORTH' && signal.color === 'YELLOW'
                        ? 'bg-amber-400 shadow-sm shadow-amber-400'
                        : 'bg-amber-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'NORTH' && signal.color === 'GREEN'
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse'
                        : 'bg-emerald-950'
                    }`}
                  />
                </div>
                <div className="text-[11px] font-mono text-left">
                  <div className="font-bold text-slate-200">NORTH</div>
                  <div className="text-slate-400">{selectedIntersection.directionalCounts.NORTH} veh ({signal.timings.NORTH}s)</div>
                </div>
              </div>
            </div>

            {/* SOUTH Approach Signal & Queue */}
            <div className="absolute bottom-3 flex flex-col items-center z-20">
              <div
                className={`p-2 rounded-xl border flex items-center gap-2 ${
                  signal.activeDirection === 'SOUTH'
                    ? 'bg-slate-900/95 border-emerald-500/80 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col gap-1 items-center bg-black/80 p-1 rounded border border-slate-700">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'SOUTH' && signal.color === 'RED'
                        ? 'bg-red-500 shadow-sm shadow-red-500'
                        : 'bg-red-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'SOUTH' && signal.color === 'YELLOW'
                        ? 'bg-amber-400 shadow-sm shadow-amber-400'
                        : 'bg-amber-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'SOUTH' && signal.color === 'GREEN'
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse'
                        : 'bg-emerald-950'
                    }`}
                  />
                </div>
                <div className="text-[11px] font-mono text-left">
                  <div className="font-bold text-slate-200">SOUTH</div>
                  <div className="text-slate-400">{selectedIntersection.directionalCounts.SOUTH} veh ({signal.timings.SOUTH}s)</div>
                </div>
              </div>
            </div>

            {/* WEST Approach Signal & Queue */}
            <div className="absolute left-3 flex items-center z-20">
              <div
                className={`p-2 rounded-xl border flex items-center gap-2 ${
                  signal.activeDirection === 'WEST'
                    ? 'bg-slate-900/95 border-emerald-500/80 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col gap-1 items-center bg-black/80 p-1 rounded border border-slate-700">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'WEST' && signal.color === 'RED'
                        ? 'bg-red-500 shadow-sm shadow-red-500'
                        : 'bg-red-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'WEST' && signal.color === 'YELLOW'
                        ? 'bg-amber-400 shadow-sm shadow-amber-400'
                        : 'bg-amber-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'WEST' && signal.color === 'GREEN'
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse'
                        : 'bg-emerald-950'
                    }`}
                  />
                </div>
                <div className="text-[11px] font-mono text-left">
                  <div className="font-bold text-slate-200">WEST</div>
                  <div className="text-slate-400">{selectedIntersection.directionalCounts.WEST} veh ({signal.timings.WEST}s)</div>
                </div>
              </div>
            </div>

            {/* EAST Approach Signal & Queue */}
            <div className="absolute right-3 flex items-center z-20">
              <div
                className={`p-2 rounded-xl border flex items-center gap-2 ${
                  signal.activeDirection === 'EAST'
                    ? 'bg-slate-900/95 border-emerald-500/80 shadow-lg shadow-emerald-500/20'
                    : 'bg-slate-900/80 border-slate-800'
                }`}
              >
                <div className="flex flex-col gap-1 items-center bg-black/80 p-1 rounded border border-slate-700">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'EAST' && signal.color === 'RED'
                        ? 'bg-red-500 shadow-sm shadow-red-500'
                        : 'bg-red-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'EAST' && signal.color === 'YELLOW'
                        ? 'bg-amber-400 shadow-sm shadow-amber-400'
                        : 'bg-amber-950'
                    }`}
                  />
                  <span
                    className={`w-2 h-2 rounded-full ${
                      signal.activeDirection === 'EAST' && signal.color === 'GREEN'
                        ? 'bg-emerald-400 shadow-sm shadow-emerald-400 animate-pulse'
                        : 'bg-emerald-950'
                    }`}
                  />
                </div>
                <div className="text-[11px] font-mono text-left">
                  <div className="font-bold text-slate-200">EAST</div>
                  <div className="text-slate-400">{selectedIntersection.directionalCounts.EAST} veh ({signal.timings.EAST}s)</div>
                </div>
              </div>
            </div>
          </div>

          {/* Cyclic Progression Legend */}
          <div className="mt-3 p-3 bg-slate-900/60 rounded-xl border border-slate-800/80 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Cyclic Movement Order:</span>
            <div className="flex items-center gap-2 text-slate-200">
              <span className={signal.activeDirection === 'NORTH' ? 'text-emerald-400 font-bold' : ''}>NORTH</span>
              <ArrowRight className="w-3 h-3 text-slate-600" />
              <span className={signal.activeDirection === 'EAST' ? 'text-emerald-400 font-bold' : ''}>EAST</span>
              <ArrowRight className="w-3 h-3 text-slate-600" />
              <span className={signal.activeDirection === 'SOUTH' ? 'text-emerald-400 font-bold' : ''}>SOUTH</span>
              <ArrowRight className="w-3 h-3 text-slate-600" />
              <span className={signal.activeDirection === 'WEST' ? 'text-emerald-400 font-bold' : ''}>WEST</span>
            </div>
            <span className="text-blue-400 font-medium">Next: {nextDir}</span>
          </div>
        </div>

        {/* Right Column: Controller Operations & Adaptive Optimization (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Optimization Engine Card */}
          <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-400" />
                <h3 className="text-sm font-semibold text-white">Dynamic Adaptive Signal Optimizer</h3>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                Algorithm Active
              </span>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Reads latest queue lengths across all four directional approaches and recalculates optimum green durations to maximize junction throughput.
            </p>

            {/* Formula Explainer */}
            <div className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-[11px] font-mono space-y-1 text-slate-300">
              <div className="text-slate-400 font-bold">Transparent Optimization Formula:</div>
              <code className="text-blue-300 block">
                greenTime = minGreen + (vehCount / totalVeh) * adjustableBudget
              </code>
              <div className="text-[10px] text-slate-500 mt-1">
                Clamped between 10s min and 60s max. Preserves pedestrian crossing safety floor.
              </div>
            </div>

            <button
              onClick={() => runOptimization(selectedIntersection.id)}
              className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl text-xs font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white shadow-lg shadow-blue-600/25 transition active:scale-95"
            >
              <Zap className="w-4 h-4 text-yellow-300" />
              Run Adaptive Optimization on this Node
            </button>

            {/* Latest Optimization Audit Output */}
            {latestLog && (
              <div className="p-3.5 bg-slate-900/90 rounded-xl border border-blue-500/30 text-xs space-y-2">
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-blue-400 font-bold">Latest Optimization Result</span>
                  <span className="text-slate-400">{latestLog.timestamp}</span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-center text-xs font-mono">
                  {(['NORTH', 'SOUTH', 'EAST', 'WEST'] as const).map((dir) => (
                    <div key={dir} className="p-2 bg-slate-800/80 rounded-lg border border-slate-700/80">
                      <div className="text-[10px] text-slate-400">{dir}</div>
                      <div className="text-white font-bold">{latestLog.recommendedTimings[dir]}s</div>
                      <div className="text-[9px] text-slate-400">
                        was {latestLog.previousTimings[dir]}s
                      </div>
                    </div>
                  ))}
                </div>

                <p className="text-[11px] text-slate-300 leading-relaxed italic bg-blue-950/30 p-2 rounded border border-blue-500/20">
                  &ldquo;{latestLog.rationale}&rdquo;
                </p>

                <div className="flex items-center justify-between text-[11px] font-mono text-emerald-400 pt-1">
                  <span>Est. Delay Reduction: ~{latestLog.estimatedDelayReductionSec}s</span>
                  <span>Fuel Saved: ~{latestLog.estimatedFuelSavedLiters} L</span>
                </div>
              </div>
            )}
          </div>

          {/* Manual Signal Override Card */}
          <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-purple-400" />
                <h3 className="text-sm font-semibold text-white">Manual Supervisor Override</h3>
              </div>
              <span className="text-[10px] font-mono text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/20">
                Classroom Demo Tool
              </span>
            </div>

            <p className="text-xs text-slate-300">
              Force an intersection approach to a fixed signal state. Interlock controller automatically enforces red states on conflicting cross-streets.
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-slate-400 font-mono mb-1">Target Direction</label>
                <select
                  value={overrideDir}
                  onChange={(e) => setOverrideDir(e.target.value as Direction)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs"
                >
                  <option value="NORTH">NORTH Corridor</option>
                  <option value="SOUTH">SOUTH Corridor</option>
                  <option value="EAST">EAST Corridor</option>
                  <option value="WEST">WEST Corridor</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Forced Signal State</label>
                <select
                  value={overrideCol}
                  onChange={(e) => setOverrideCol(e.target.value as SignalColor)}
                  className="w-full bg-slate-900 border border-slate-700 text-white rounded-xl px-3 py-2 text-xs"
                >
                  <option value="GREEN">GREEN (Clear Queue)</option>
                  <option value="YELLOW">YELLOW (Caution Phase)</option>
                  <option value="RED">RED (Halt Traffic)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleApplyOverride}
                className="flex-1 py-2 rounded-xl text-xs font-semibold bg-purple-600 hover:bg-purple-500 text-white transition active:scale-95"
              >
                Apply Manual Override
              </button>
              {signal.isManualOverride && (
                <button
                  onClick={handleDisableOverride}
                  className="px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
                  title="Restore Automatic"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
              )}
            </div>

            <div className="text-[10px] text-slate-500 font-mono flex items-start gap-1.5 pt-1">
              <Info className="w-3.5 h-3.5 shrink-0 mt-0.5 text-slate-400" />
              <span>Simulated prototype does not replace certified NEMA/170/2070 traffic safety hardware controllers.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
