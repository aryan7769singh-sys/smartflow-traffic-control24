import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  Car,
  Truck,
  Bus,
  ShieldAlert,
  Search,
  Plus,
  Flame,
  Zap,
  ArrowRight,
  Clock,
  Compass,
  AlertTriangle,
  Info,
  X,
  CheckCircle,
} from 'lucide-react';
import { Direction, Vehicle, VehicleCategory, VehicleStatus } from '../types/traffic';

export const VehiclesPage: React.FC = () => {
  const {
    vehicles,
    intersections,
    addVehicle,
    dispatchEmergencyVehicle,
    clearEmergencyRoute,
    emergencyProposal,
  } = useTraffic();

  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'ALL' | VehicleCategory>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | VehicleStatus>('ALL');

  // Add Vehicle Modal
  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newCategory, setNewCategory] = useState<VehicleCategory>('Car');
  const [newIntersectionId, setNewIntersectionId] = useState(intersections[0]?.id || 'INT-DEL-01');
  const [newDirection, setNewDirection] = useState<Direction>('NORTH');
  const [newPlate, setNewPlate] = useState('');

  // Emergency Dispatch Modal
  const [isEmergencyDispatchOpen, setIsEmergencyDispatchOpen] = useState(false);
  const [emgType, setEmgType] = useState<'Ambulance' | 'Fire Engine' | 'Police Cruiser'>('Ambulance');
  const [emgTargetId, setEmgTargetId] = useState(intersections[1]?.id || 'INT-DEL-02');
  const [emgDirection, setEmgDirection] = useState<Direction>('NORTH');

  const filteredVehicles = vehicles.filter((v) => {
    const matchSearch =
      v.licensePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.intersectionName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchCat = categoryFilter === 'ALL' || v.category === categoryFilter;
    const matchStatus = statusFilter === 'ALL' || v.status === statusFilter;
    return matchSearch && matchCat && matchStatus;
  });

  const handleCreateVehicle = (e: React.FormEvent) => {
    e.preventDefault();
    addVehicle({
      category: newCategory,
      intersectionId: newIntersectionId,
      direction: newDirection,
      licensePlate: newPlate.trim() || `DL-01-XX-${Math.floor(1000 + Math.random() * 9000)}`,
      speedKmph: newCategory === 'Motorcycle' ? 45 : newCategory === 'Truck' ? 25 : 35,
      estimatedArrivalSec: 20,
    });
    setIsAddOpen(false);
    setNewPlate('');
  };

  const handleDispatchEmergency = (e: React.FormEvent) => {
    e.preventDefault();
    dispatchEmergencyVehicle(emgType, emgTargetId, emgDirection);
    setIsEmergencyDispatchOpen(false);
  };

  const getCategoryIcon = (category: VehicleCategory) => {
    switch (category) {
      case 'Emergency':
        return <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />;
      case 'Bus':
        return <Bus className="w-4 h-4 text-amber-400 shrink-0" />;
      case 'Truck':
        return <Truck className="w-4 h-4 text-orange-400 shrink-0" />;
      case 'Motorcycle':
        return <Compass className="w-4 h-4 text-cyan-400 shrink-0" />;
      case 'Car':
      default:
        return <Car className="w-4 h-4 text-blue-400 shrink-0" />;
    }
  };

  const getStatusBadge = (status: VehicleStatus) => {
    switch (status) {
      case 'Approaching':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-400 border border-blue-500/30">Approaching</span>;
      case 'Waiting':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/30">In Queue</span>;
      case 'Priority Routed':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse">Priority Green</span>;
      case 'Passed':
        return <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">Passed</span>;
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Vehicle Fleet Telemetry & Emergency Preemption
            <span className="text-xs font-mono font-normal text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
              {vehicles.length} Tracked Units
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Simulated loop-detector vehicle records, directional movement queues, and emergency green-wave preemption demonstrations.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsEmergencyDispatchOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white shadow-lg shadow-red-600/25 transition active:scale-95"
          >
            <ShieldAlert className="w-4 h-4 text-white" />
            Dispatch Emergency Vehicle
          </button>

          <button
            onClick={() => setIsAddOpen(true)}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <Plus className="w-4 h-4 text-blue-400" />
            Add Simulated Vehicle
          </button>
        </div>
      </div>

      {/* Emergency Active Corridor Banner */}
      {emergencyProposal && (
        <div className="bg-gradient-to-r from-red-950/90 via-[#1E1120] to-red-950/90 border border-red-500/60 rounded-2xl p-5 shadow-2xl space-y-3">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-red-600 text-white shadow-lg shadow-red-600/40">
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono font-black uppercase bg-red-500 text-white">
                    Emergency Priority Mode Active
                  </span>
                  <span className="text-xs text-slate-400 font-mono">
                    ID: {emergencyProposal.id}
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mt-1">
                  {emergencyProposal.category} ({emergencyProposal.vehiclePlate}) &rarr; {emergencyProposal.targetIntersectionName}
                </h3>
                <p className="text-xs text-red-200/90 mt-0.5">
                  Dynamic green wave corridor opened on <strong>{emergencyProposal.priorityDirection} Corridor</strong>. Conflicting movements locked to red.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="text-[10px] uppercase font-mono text-slate-400 block">Corridor Hold Time</span>
                <span className="text-xl font-bold font-mono text-red-400">{emergencyProposal.greenWaveDurationSec}s</span>
              </div>
              <button
                onClick={clearEmergencyRoute}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
              >
                Clear Green Wave
              </button>
            </div>
          </div>

          <div className="p-3 bg-black/40 rounded-xl border border-red-500/20 text-[11px] text-slate-400 flex items-start gap-2">
            <Info className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <span>
              <strong>Deployment Advisory Note:</strong> In production smart cities, emergency preemption requires mutual radio beacons (DSRC/C-V2X), cryptographic authentication, GPS telemetry, and fail-safe coordination with certified traffic signal hardware.
            </span>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-[#131D31] p-4 rounded-2xl border border-slate-800/90 flex flex-wrap items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by license plate, target intersection, or vehicle ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500"
          />
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          {(['ALL', 'Car', 'Motorcycle', 'Bus', 'Truck', 'Emergency'] as const).map((cat) => (
            <button
              key={cat}
              onClick={() => setCategoryFilter(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                categoryFilter === cat
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          {(['ALL', 'Approaching', 'Waiting', 'Passed'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Vehicle Roster Table */}
      <div className="bg-[#131D31] rounded-2xl border border-slate-800/90 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[11px] uppercase font-mono text-slate-400 border-b border-slate-800 bg-slate-900/60">
              <tr>
                <th className="py-3 px-4">Vehicle ID & Plate</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Target Intersection</th>
                <th className="py-3 px-3">Approach Direction</th>
                <th className="py-3 px-3">Est. Speed</th>
                <th className="py-3 px-3">Arrival ETA</th>
                <th className="py-3 px-4 text-right">Telemetry Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filteredVehicles.map((vehicle) => (
                <tr key={vehicle.id} className="hover:bg-slate-900/40 transition">
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-white font-mono flex items-center gap-2">
                      {vehicle.licensePlate}
                      <span className="text-[10px] text-slate-400">{vehicle.id}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3">
                    <div className="flex items-center gap-2 font-medium text-slate-200">
                      {getCategoryIcon(vehicle.category)}
                      <span>{vehicle.category}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-3 text-slate-300 font-medium">
                    {vehicle.intersectionName}
                  </td>
                  <td className="py-3.5 px-3 font-mono font-semibold text-slate-200">
                    {vehicle.direction}
                  </td>
                  <td className="py-3.5 px-3 font-mono text-slate-400">
                    {vehicle.speedKmph} km/h
                  </td>
                  <td className="py-3.5 px-3 font-mono text-cyan-400">
                    {vehicle.estimatedArrivalSec > 0 ? `${vehicle.estimatedArrivalSec}s` : 'At stopline'}
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    {getStatusBadge(vehicle.status)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Dispatch Emergency Vehicle Modal */}
      {isEmergencyDispatchOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleDispatchEmergency}
            className="bg-[#131D31] border border-red-500/50 rounded-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-red-400">
                <ShieldAlert className="w-5 h-5" />
                <h3 className="text-base font-bold text-white">Emergency Vehicle Dispatch Simulator</h3>
              </div>
              <button
                type="button"
                onClick={() => setIsEmergencyDispatchOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Demonstrates simulated signal priority preemption: Upon dispatch, the target junction instantly clears conflicting lanes and holds an uninterrupted green wave corridor for safe passage.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-mono mb-1">Emergency Service Type</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Ambulance', 'Fire Engine', 'Police Cruiser'] as const).map((type) => (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setEmgType(type)}
                      className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition ${
                        emgType === type
                          ? 'bg-red-600 text-white border-red-500 shadow-lg shadow-red-600/30'
                          : 'bg-slate-900 border-slate-800 text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Target Junction</label>
                <select
                  value={emgTargetId}
                  onChange={(e) => setEmgTargetId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs"
                >
                  {intersections.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name} ({i.locationArea})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Approach Corridor</label>
                <select
                  value={emgDirection}
                  onChange={(e) => setEmgDirection(e.target.value as Direction)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs"
                >
                  <option value="NORTH">NORTH Approach</option>
                  <option value="SOUTH">SOUTH Approach</option>
                  <option value="EAST">EAST Approach</option>
                  <option value="WEST">WEST Approach</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsEmergencyDispatchOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-red-600 hover:bg-red-500 text-white shadow-lg shadow-red-600/30 transition"
              >
                Dispatch & Force Green Wave
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Add Simulated Vehicle Modal */}
      {isAddOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleCreateVehicle}
            className="bg-[#131D31] border border-slate-800 rounded-2xl max-w-md w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Add Simulated Vehicle</h3>
              <button
                type="button"
                onClick={() => setIsAddOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 font-mono mb-1">Vehicle Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as VehicleCategory)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs"
                >
                  <option value="Car">Passenger Car</option>
                  <option value="Motorcycle">Motorcycle / Two-Wheeler</option>
                  <option value="Bus">Public Transit Bus</option>
                  <option value="Truck">Heavy Commercial Truck</option>
                  <option value="Emergency">Emergency Vehicle</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Target Intersection</label>
                <select
                  value={newIntersectionId}
                  onChange={(e) => setNewIntersectionId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs"
                >
                  {intersections.map((i) => (
                    <option key={i.id} value={i.id}>
                      {i.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">Direction</label>
                <select
                  value={newDirection}
                  onChange={(e) => setNewDirection(e.target.value as Direction)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs"
                >
                  <option value="NORTH">NORTH</option>
                  <option value="SOUTH">SOUTH</option>
                  <option value="EAST">EAST</option>
                  <option value="WEST">WEST</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 font-mono mb-1">License Plate (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. DL-01-AB-1234"
                  value={newPlate}
                  onChange={(e) => setNewPlate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 text-white rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition"
              >
                Add Vehicle
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
