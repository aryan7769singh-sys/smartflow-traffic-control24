import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  AlertTriangle,
  ShieldAlert,
  Search,
  Filter,
  CheckCircle2,
  Check,
  Trash2,
  ArrowRight,
  Clock,
  MapPin,
  Info,
} from 'lucide-react';
import { AlertSeverity, AlertStatus, TrafficAlert } from '../types/traffic';

export const AlertsPage: React.FC = () => {
  const {
    alerts,
    acknowledgeAlert,
    resolveAlert,
    clearResolvedAlerts,
    setActiveTab,
    setSelectedIntersectionId,
  } = useTraffic();

  const [searchTerm, setSearchTerm] = useState('');
  const [severityFilter, setSeverityFilter] = useState<'ALL' | AlertSeverity>('ALL');
  const [statusFilter, setStatusFilter] = useState<'ALL' | AlertStatus>('ALL');
  const [isClearConfirmOpen, setIsClearConfirmOpen] = useState(false);

  const filteredAlerts = alerts.filter((alert) => {
    const matchesSearch =
      alert.intersectionName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      alert.type.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSeverity = severityFilter === 'ALL' || alert.severity === severityFilter;
    const matchesStatus = statusFilter === 'ALL' || alert.status === statusFilter;

    return matchesSearch && matchesSeverity && matchesStatus;
  });

  const activeCount = alerts.filter((a) => a.status === 'ACTIVE').length;
  const acknowledgedCount = alerts.filter((a) => a.status === 'ACKNOWLEDGED').length;
  const resolvedCount = alerts.filter((a) => a.status === 'RESOLVED').length;

  const getSeverityStyle = (severity: AlertSeverity) => {
    switch (severity) {
      case 'CRITICAL':
        return 'bg-rose-500/15 border-rose-500/40 text-rose-300';
      case 'HIGH':
        return 'bg-orange-500/15 border-orange-500/40 text-orange-300';
      case 'MEDIUM':
        return 'bg-amber-500/15 border-amber-500/40 text-amber-300';
      case 'LOW':
        return 'bg-blue-500/15 border-blue-500/40 text-blue-300';
    }
  };

  const getStatusBadge = (status: AlertStatus) => {
    switch (status) {
      case 'ACTIVE':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-red-500/20 text-red-400 border border-red-500/30 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-red-400" />
            ACTIVE
          </span>
        );
      case 'ACKNOWLEDGED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-amber-500/20 text-amber-300 border border-amber-500/30">
            <Clock className="w-3 h-3 text-amber-400" />
            ACKNOWLEDGED
          </span>
        );
      case 'RESOLVED':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold font-mono bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            RESOLVED
          </span>
        );
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Congestion & Incident Alert Management
            <span className="text-xs font-mono font-normal text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
              {activeCount} Active Breaches
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time threshold surveillance: Density overflows, prolonged queue delays, and emergency corridors.
          </p>
        </div>

        {resolvedCount > 0 && (
          <button
            onClick={() => setIsClearConfirmOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
          >
            <Trash2 className="w-3.5 h-3.5 text-rose-400" />
            Clear Resolved Records ({resolvedCount})
          </button>
        )}
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-[#131D31] border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">Active Unresolved Alerts</span>
            <div className="text-2xl font-bold font-mono text-rose-400 mt-1">{activeCount}</div>
          </div>
          <ShieldAlert className="w-8 h-8 text-rose-500/40" />
        </div>

        <div className="bg-[#131D31] border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">Under Observation</span>
            <div className="text-2xl font-bold font-mono text-amber-400 mt-1">{acknowledgedCount}</div>
          </div>
          <Clock className="w-8 h-8 text-amber-500/40" />
        </div>

        <div className="bg-[#131D31] border border-slate-800 rounded-xl p-4 flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-400 font-medium">Resolved & Normalised</span>
            <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">{resolvedCount}</div>
          </div>
          <CheckCircle2 className="w-8 h-8 text-emerald-500/40" />
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-[#131D31] p-4 rounded-2xl border border-slate-800/90 flex flex-wrap items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search alerts by junction, description, or alert ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 transition"
          />
        </div>

        {/* Severity filter */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          <span className="text-[10px] uppercase font-mono text-slate-500 px-2 font-bold">Severity:</span>
          {(['ALL', 'CRITICAL', 'HIGH', 'MEDIUM', 'LOW'] as const).map((sev) => (
            <button
              key={sev}
              onClick={() => setSeverityFilter(sev)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                severityFilter === sev
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {sev}
            </button>
          ))}
        </div>

        {/* Status filter */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
          <span className="text-[10px] uppercase font-mono text-slate-500 px-2 font-bold">Status:</span>
          {(['ALL', 'ACTIVE', 'ACKNOWLEDGED', 'RESOLVED'] as const).map((st) => (
            <button
              key={st}
              onClick={() => setStatusFilter(st)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                statusFilter === st
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {st}
            </button>
          ))}
        </div>
      </div>

      {/* Alerts Stream List */}
      <div className="space-y-3">
        {filteredAlerts.length === 0 ? (
          <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-400/50 mx-auto" />
            <h3 className="text-sm font-semibold text-white">No Matching Traffic Alerts</h3>
            <p className="text-xs text-slate-500">
              Corridor density thresholds are currently within nominal limits or no records match your filter criteria.
            </p>
          </div>
        ) : (
          filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`bg-[#131D31] border rounded-2xl p-5 transition-all ${
                alert.status === 'ACTIVE'
                  ? 'border-slate-800 hover:border-slate-700 shadow-md'
                  : 'border-slate-800/60 opacity-80'
              }`}
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                {/* Alert Info */}
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono font-bold text-slate-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                      {alert.id}
                    </span>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${getSeverityStyle(
                        alert.severity
                      )}`}
                    >
                      {alert.severity} SEVERITY
                    </span>
                    <span className="text-[10px] font-mono font-semibold uppercase text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
                      {alert.type}
                    </span>
                    {getStatusBadge(alert.status)}
                    <span className="text-[11px] text-slate-500 font-mono ml-auto">
                      Generated at {alert.timestamp}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      {alert.intersectionName}
                    </h3>
                    <p className="text-xs text-slate-300 leading-relaxed mt-1">
                      {alert.description}
                    </p>
                  </div>

                  {alert.acknowledgedBy && (
                    <div className="text-[11px] text-slate-400 font-mono">
                      Acknowledged by: <strong className="text-slate-300">{alert.acknowledgedBy}</strong>
                    </div>
                  )}

                  {alert.resolvedAt && (
                    <div className="text-[11px] text-emerald-400/80 font-mono">
                      Resolved and normalized at: {alert.resolvedAt}
                    </div>
                  )}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap md:flex-col items-end gap-2 shrink-0">
                  {alert.status === 'ACTIVE' && (
                    <button
                      onClick={() => acknowledgeAlert(alert.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-amber-600/20 hover:bg-amber-600/30 text-amber-300 border border-amber-500/30 transition"
                    >
                      <Clock className="w-3.5 h-3.5" />
                      Acknowledge
                    </button>
                  )}

                  {alert.status !== 'RESOLVED' && (
                    <button
                      onClick={() => resolveAlert(alert.id)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 transition"
                    >
                      <Check className="w-3.5 h-3.5" />
                      Mark Resolved
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setSelectedIntersectionId(alert.intersectionId);
                      setActiveTab('map');
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium text-blue-400 hover:text-blue-300 bg-slate-900 hover:bg-slate-800 transition"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    Locate on Map
                  </button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Clear Confirmation Modal */}
      {isClearConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#131D31] border border-slate-800 rounded-2xl max-w-sm w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <h3 className="text-sm font-bold text-white">Purge Resolved Alert History?</h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              This will remove all {resolvedCount} resolved demonstration alerts from the storage roster. Active and acknowledged alerts will remain untouched.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsClearConfirmOpen(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  clearResolvedAlerts();
                  setIsClearConfirmOpen(false);
                }}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white"
              >
                Clear History
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
