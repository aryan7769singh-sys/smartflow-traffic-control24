import React from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
} from 'recharts';
import {
  GitFork,
  Car,
  AlertTriangle,
  Radio,
  Clock,
  ShieldAlert,
  Zap,
  ArrowUpRight,
  TrendingUp,
  Sliders,
  CheckCircle,
} from 'lucide-react';
import { CongestionLevel } from '../types/traffic';

export const OverviewPage: React.FC = () => {
  const {
    intersections,
    alerts,
    vehicles,
    runOptimization,
    runAllOptimizations,
    addTrafficToIntersection,
    setActiveTab,
    setSelectedIntersectionId,
    emergencyProposal,
  } = useTraffic();

  // KPI Calculations
  const totalIntersections = intersections.length;
  const totalVehiclesDetected = intersections.reduce((acc, curr) => acc + curr.totalVehicles, 0);
  const congestedCount = intersections.filter(
    (i) => i.congestionLevel === 'HIGH' || i.congestionLevel === 'CRITICAL'
  ).length;
  const activeSignals = intersections.filter((i) => i.signal.color !== 'RED').length;
  const avgWaitTime = Math.round(
    intersections.reduce((acc, curr) => acc + curr.averageWaitTimeSec, 0) / (totalIntersections || 1)
  );
  const activeAlertCount = alerts.filter((a) => a.status === 'ACTIVE').length;

  // Chart 1 Data: Time-series density trend from intersections history
  // Merge histories across intersections to get network average vehicle count over time
  const sampleHistory = intersections[0]?.history || [];
  const timeSeriesData = sampleHistory.map((pt, idx) => {
    let totalCountAtIdx = 0;
    intersections.forEach((i) => {
      const item = i.history[idx] || i.history[i.history.length - 1];
      if (item) totalCountAtIdx += item.vehicleCount;
    });
    return {
      time: pt.timeStr,
      vehicles: totalCountAtIdx,
      avgWait: Math.round(pt.avgWaitSec * 1.1),
    };
  });

  // Chart 2 Data: Traffic distribution by congestion level
  const distributionData = [
    {
      name: 'Low (0-30%)',
      value: intersections.filter((i) => i.congestionLevel === 'LOW').length,
      color: '#10B981',
    },
    {
      name: 'Moderate (31-60%)',
      value: intersections.filter((i) => i.congestionLevel === 'MODERATE').length,
      color: '#F59E0B',
    },
    {
      name: 'High (61-80%)',
      value: intersections.filter((i) => i.congestionLevel === 'HIGH').length,
      color: '#F97316',
    },
    {
      name: 'Critical (81-100%)',
      value: intersections.filter((i) => i.congestionLevel === 'CRITICAL').length,
      color: '#EF4444',
    },
  ];

  const getCongestionBadge = (level: CongestionLevel) => {
    switch (level) {
      case 'LOW':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">Low</span>;
      case 'MODERATE':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-400 border border-amber-500/30">Moderate</span>;
      case 'HIGH':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-orange-500/15 text-orange-400 border border-orange-500/30">High</span>;
      case 'CRITICAL':
        return <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse">Critical</span>;
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Page Title & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Urban Traffic Command Center
            <span className="text-xs font-mono font-normal text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
              Delhi NCR Zone
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time simulated vehicular density telemetry, adaptive cycle durations, and emergency vehicle preemption.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => addTrafficToIntersection(intersections[1]?.id || 'INT-DEL-02', 35)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition active:scale-95"
            title="Inject simulated vehicles to test congestion"
          >
            <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
            +Inject Traffic (+35)
          </button>

          <button
            onClick={runAllOptimizations}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/25 transition active:scale-95"
          >
            <Zap className="w-3.5 h-3.5 text-yellow-300" />
            Run Adaptive Optimization
          </button>
        </div>
      </div>

      {/* Emergency Active Banner */}
      {emergencyProposal && (
        <div className="p-4 rounded-xl bg-red-950/70 border border-red-500/50 flex flex-wrap items-center justify-between gap-4 shadow-xl shadow-red-900/20">
          <div className="flex items-center gap-3">
            <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
            <div>
              <div className="text-xs font-bold text-red-200 uppercase tracking-wider flex items-center gap-2">
                Priority Corridor Active: {emergencyProposal.category} ({emergencyProposal.vehiclePlate})
              </div>
              <p className="text-xs text-red-300/90 mt-0.5">
                Target: <strong>{emergencyProposal.targetIntersectionName}</strong> | Preemption Phase: Green light granted on {emergencyProposal.priorityDirection} approach.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('vehicles')}
            className="px-3 py-1 rounded-lg text-xs font-semibold bg-red-600 hover:bg-red-500 text-white transition"
          >
            View Priority Route
          </button>
        </div>
      )}

      {/* 6 KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {/* KPI 1 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Surveillance Points</span>
            <GitFork className="w-4 h-4 text-blue-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">{totalIntersections}</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Key Delhi NCR junctions</div>
          </div>
        </div>

        {/* KPI 2 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Vehicles Detected</span>
            <Car className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">{totalVehiclesDetected}</div>
            <div className="text-[11px] text-indigo-300 mt-0.5 font-mono">Simulated queue load</div>
          </div>
        </div>

        {/* KPI 3 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Congested Jn</span>
            <AlertTriangle className="w-4 h-4 text-amber-400" />
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-bold font-mono ${congestedCount > 0 ? 'text-amber-400' : 'text-slate-100'}`}>
              {congestedCount}
            </div>
            <div className="text-[11px] text-amber-400/80 mt-0.5">Density &gt; 60%</div>
          </div>
        </div>

        {/* KPI 4 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Active Signals</span>
            <Radio className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-emerald-400">{activeSignals}</div>
            <div className="text-[11px] text-emerald-400/80 mt-0.5">Automated cycles</div>
          </div>
        </div>

        {/* KPI 5 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Avg Waiting Time</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold font-mono text-white">{avgWaitTime}s</div>
            <div className="text-[11px] text-slate-400 mt-0.5">Target: &lt;45s</div>
          </div>
        </div>

        {/* KPI 6 */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-xs font-medium">Active Alerts</span>
            <ShieldAlert className="w-4 h-4 text-rose-400" />
          </div>
          <div className="mt-3">
            <div className={`text-2xl font-bold font-mono ${activeAlertCount > 0 ? 'text-rose-400' : 'text-slate-100'}`}>
              {activeAlertCount}
            </div>
            <div className="text-[11px] text-rose-400/80 mt-0.5">Requires observation</div>
          </div>
        </div>
      </div>

      {/* Charts Section: Density Time Series + Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* A. Traffic Density Chart */}
        <div className="lg:col-span-2 bg-[#131D31] border border-slate-800/90 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Network Traffic Density Trends</h3>
              <p className="text-xs text-slate-400">Total detected vehicles and average queue delay across simulation ticks</p>
            </div>
            <span className="text-[11px] font-mono text-blue-400 bg-blue-500/10 px-2.5 py-1 rounded-md border border-blue-500/20">
              Live Stream
            </span>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeriesData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="vehiclesGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3B82F6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#3B82F6" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="waitGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10B981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="time" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Area type="monotone" dataKey="vehicles" name="Total Vehicles" stroke="#3B82F6" strokeWidth={2} fillOpacity={1} fill="url(#vehiclesGrad)" />
                <Area type="monotone" dataKey="avgWait" name="Wait Time (s)" stroke="#10B981" strokeWidth={2} fillOpacity={1} fill="url(#waitGrad)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* B. Traffic Distribution Chart */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">Congestion Distribution</h3>
            <p className="text-xs text-slate-400 mb-2">Breakdown of 8 monitored intersections</p>
          </div>
          <div className="h-56 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend
                  verticalAlign="bottom"
                  iconType="circle"
                  wrapperStyle={{ fontSize: '11px', paddingTop: '10px' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* E. Signal Status Overview Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Radio className="w-4 h-4 text-blue-400" />
            Live Intersection Signal Overview
          </h3>
          <button
            onClick={() => setActiveTab('signals')}
            className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 transition"
          >
            Manage Timings <ArrowUpRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {intersections.map((intersection) => {
            const signal = intersection.signal;
            const isGreen = signal.color === 'GREEN';
            const isYellow = signal.color === 'YELLOW';

            return (
              <div
                key={intersection.id}
                onClick={() => {
                  setSelectedIntersectionId(intersection.id);
                  setActiveTab('signals');
                }}
                className="bg-[#131D31] hover:bg-[#1A253F] border border-slate-800/80 hover:border-blue-500/40 rounded-xl p-4 transition-all cursor-pointer group"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-xs font-semibold text-slate-200 group-hover:text-blue-300 transition-colors">
                      {intersection.name}
                    </h4>
                    <p className="text-[10px] text-slate-500 font-mono mt-0.5">{intersection.id}</p>
                  </div>
                  {getCongestionBadge(intersection.congestionLevel)}
                </div>

                {/* Simulated Signal Display */}
                <div className="mt-3 flex items-center justify-between bg-slate-900/80 p-2.5 rounded-lg border border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="flex flex-col gap-1 items-center bg-black/60 p-1 rounded-md border border-slate-800">
                      <span className={`w-2.5 h-2.5 rounded-full ${signal.color === 'RED' ? 'bg-red-500 shadow-lg shadow-red-500/80' : 'bg-red-950'}`} />
                      <span className={`w-2.5 h-2.5 rounded-full ${isYellow ? 'bg-yellow-400 shadow-lg shadow-yellow-400/80' : 'bg-yellow-950'}`} />
                      <span className={`w-2.5 h-2.5 rounded-full ${isGreen ? 'bg-emerald-500 shadow-lg shadow-emerald-500/80 animate-pulse' : 'bg-emerald-950'}`} />
                    </div>
                    <div>
                      <div className="text-[10px] uppercase font-mono text-slate-400">Phase Active</div>
                      <div className="text-xs font-bold text-white font-mono">{signal.activeDirection}</div>
                    </div>
                  </div>

                  <div className="text-right">
                    <div className="text-[10px] text-slate-400 font-mono">Remaining</div>
                    <div className="text-lg font-mono font-bold text-emerald-400">
                      {signal.timeRemainingSec}s
                    </div>
                  </div>
                </div>

                <div className="mt-2.5 flex items-center justify-between text-[11px] text-slate-400">
                  <span>Vehicles: <strong className="text-slate-200">{intersection.totalVehicles}</strong></span>
                  <span>Wait: <strong className="text-slate-200">{intersection.averageWaitTimeSec}s</strong></span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* C. Intersection Status Table & D. Recent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Status Table (2 cols) */}
        <div className="lg:col-span-2 bg-[#131D31] border border-slate-800/90 rounded-2xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-white">Intersection Surveillance Roster</h3>
              <p className="text-xs text-slate-400">Live operational telemetry and automated signal status</p>
            </div>
            <button
              onClick={() => setActiveTab('intersections')}
              className="text-xs text-blue-400 hover:text-blue-300 font-medium flex items-center gap-1 transition"
            >
              Full Registry <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="text-[11px] uppercase font-mono text-slate-400 border-b border-slate-800 bg-slate-900/30">
                <tr>
                  <th className="py-2.5 px-3">Intersection</th>
                  <th className="py-2.5 px-3">Vehicles</th>
                  <th className="py-2.5 px-3">Density</th>
                  <th className="py-2.5 px-3">Active Signal</th>
                  <th className="py-2.5 px-3">Avg Wait</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-sans">
                {intersections.map((intersection) => (
                  <tr key={intersection.id} className="hover:bg-slate-900/40 transition">
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-200">{intersection.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{intersection.locationArea}</div>
                    </td>
                    <td className="py-3 px-3 font-mono font-medium text-slate-200">
                      {intersection.totalVehicles}
                    </td>
                    <td className="py-3 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-full rounded-full ${
                              intersection.densityPercentage > 80
                                ? 'bg-red-500'
                                : intersection.densityPercentage > 60
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${intersection.densityPercentage}%` }}
                          />
                        </div>
                        <span className="font-mono text-[11px] text-slate-300">
                          {intersection.densityPercentage}%
                        </span>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span className="inline-flex items-center gap-1 font-mono text-[11px] font-semibold text-emerald-400">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                        {intersection.signal.activeDirection} ({intersection.signal.timeRemainingSec}s)
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-300">
                      {intersection.averageWaitTimeSec}s
                    </td>
                    <td className="py-3 px-3">
                      {getCongestionBadge(intersection.congestionLevel)}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => runOptimization(intersection.id)}
                        className="px-2.5 py-1 rounded bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 font-semibold transition"
                        title="Run adaptive algorithm for this junction"
                      >
                        Optimize
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* D. Recent Alerts Feed (1 col) */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-semibold text-white flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Active Alerts Feed
              </h3>
              <button
                onClick={() => setActiveTab('alerts')}
                className="text-xs text-blue-400 hover:text-blue-300 font-medium transition"
              >
                View All
              </button>
            </div>
            <p className="text-xs text-slate-400 mb-3">
              Real-time threshold breaches & queue events
            </p>

            <div className="space-y-2.5 overflow-y-auto max-h-[380px] pr-1">
              {alerts.slice(0, 5).map((alert) => (
                <div
                  key={alert.id}
                  className={`p-3 rounded-xl border text-xs space-y-1 ${
                    alert.severity === 'CRITICAL'
                      ? 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                      : alert.severity === 'HIGH'
                      ? 'bg-amber-950/30 border-amber-500/40 text-amber-200'
                      : 'bg-slate-900/60 border-slate-800 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between text-[10px] font-mono">
                    <span className="font-bold uppercase tracking-wider">{alert.type}</span>
                    <span className="text-slate-400">{alert.timestamp}</span>
                  </div>
                  <div className="font-semibold text-slate-100">{alert.intersectionName}</div>
                  <p className="text-[11px] text-slate-300 leading-relaxed">{alert.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 text-center">
            <span className="text-[11px] text-slate-500 font-mono">
              Sensors operate with 40s debounce logic to prevent alert flood.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
