export type Direction = 'NORTH' | 'SOUTH' | 'EAST' | 'WEST';
export type SignalColor = 'GREEN' | 'YELLOW' | 'RED';
export type CongestionLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CRITICAL';
export type AlertSeverity = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
export type AlertStatus = 'ACTIVE' | 'ACKNOWLEDGED' | 'RESOLVED';
export type VehicleCategory = 'Car' | 'Motorcycle' | 'Bus' | 'Truck' | 'Emergency';
export type VehicleStatus = 'Approaching' | 'Waiting' | 'Passed' | 'Priority Routed';

export interface DirectionalCounts {
  NORTH: number;
  SOUTH: number;
  EAST: number;
  WEST: number;
}

export interface DirectionalTimings {
  NORTH: number;
  SOUTH: number;
  EAST: number;
  WEST: number;
}

export interface IntersectionSignal {
  activeDirection: Direction;
  color: SignalColor;
  timeRemainingSec: number;
  timings: DirectionalTimings;
  isManualOverride: boolean;
  overrideColor?: SignalColor;
  overrideDirection?: Direction;
  yellowDurationSec: number;
  cycleTotalSec: number;
}

export interface HistoryPoint {
  timeStr: string;
  vehicleCount: number;
  density: number;
  avgWaitSec: number;
}

export interface Intersection {
  id: string;
  name: string;
  locationArea: string;
  coordinates: [number, number]; // [lat, lng]
  directionalCounts: DirectionalCounts;
  totalVehicles: number;
  densityPercentage: number;
  congestionLevel: CongestionLevel;
  averageWaitTimeSec: number;
  signal: IntersectionSignal;
  lastOptimizedAt?: string;
  history: HistoryPoint[];
  cameraStatus: 'ONLINE' | 'STANDBY' | 'DEGRADED';
  sensorStatus: 'ACTIVE_SIMULATED' | 'CALIBRATING';
}

export interface TrafficAlert {
  id: string;
  intersectionId: string;
  intersectionName: string;
  type: 'CONGESTION' | 'WAIT_EXCEEDED' | 'SURGE_DETECTED' | 'EMERGENCY_PRIORITY' | 'MANUAL_OVERRIDE';
  severity: AlertSeverity;
  description: string;
  timestamp: string;
  status: AlertStatus;
  acknowledgedBy?: string;
  resolvedAt?: string;
}

export interface Vehicle {
  id: string;
  category: VehicleCategory;
  intersectionId: string;
  intersectionName: string;
  direction: Direction;
  speedKmph: number;
  estimatedArrivalSec: number;
  status: VehicleStatus;
  isEmergency: boolean;
  licensePlate: string;
}

export interface OptimizationLog {
  id: string;
  timestamp: string;
  intersectionId: string;
  intersectionName: string;
  previousTimings: DirectionalTimings;
  recommendedTimings: DirectionalTimings;
  rationale: string;
  estimatedDelayReductionSec: number;
  estimatedFuelSavedLiters: number;
}

export interface ActivityItem {
  id: string;
  timestamp: string;
  type: 'SIM' | 'SIGNAL' | 'ALERT' | 'OPTIMIZE' | 'EMERGENCY' | 'OVERRIDE';
  message: string;
  level: 'info' | 'warning' | 'alert' | 'success';
}

export interface SystemSettings {
  simulationSpeed: number; // 0.5, 1, 2, 5
  updateIntervalMs: number;
  thresholds: {
    low: number;       // default 30%
    moderate: number;  // default 60%
    high: number;      // default 80%
    critical: number;  // default 100%
  };
  maxVehicleCapacityPerIntersection: number; // default 200
  waitTimeAlertThresholdSec: number;        // default 60s
  minGreenSec: number;                      // default 10s
  maxGreenSec: number;                      // default 60s
  enableAudioAlerts: boolean;
  enableAutoOptimization: boolean;
  enableEmergencyAutoPriority: boolean;
}

export interface EmergencyRouteProposal {
  id: string;
  timestamp: string;
  vehiclePlate: string;
  category: 'Ambulance' | 'Fire Engine' | 'Police Cruiser';
  targetIntersectionId: string;
  targetIntersectionName: string;
  priorityDirection: Direction;
  greenWaveDurationSec: number;
  status: 'PENDING' | 'DISPATCHED' | 'ACTIVE_GREEN' | 'CLEARED';
}
