import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  Search,
  Filter,
  Plus,
  Trash2,
  Edit2,
  Eye,
  ArrowUpDown,
  TrendingUp,
  X,
  Check,
  AlertTriangle,
  GitFork,
  Radio,
  Clock,
  Car,
} from 'lucide-react';
import { CongestionLevel, Direction, Intersection } from '../types/traffic';

export const IntersectionsPage: React.FC = () => {
  const {
    intersections,
    addIntersection,
    updateIntersection,
    deleteIntersection,
    addTrafficToIntersection,
    runOptimization,
    alerts,
  } = useTraffic();

  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState<'ALL' | CongestionLevel>('ALL');
  const [sortField, setSortField] = useState<'name' | 'vehicles' | 'density' | 'wait'>('vehicles');
  const [sortAsc, setSortAsc] = useState(false);

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingIntersection, setEditingIntersection] = useState<Intersection | null>(null);
  const [viewingIntersection, setViewingIntersection] = useState<Intersection | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Form states
  const [formName, setFormName] = useState('');
  const [formArea, setFormArea] = useState('');
  const [formNorth, setFormNorth] = useState(25);
  const [formSouth, setFormSouth] = useState(25);
  const [formEast, setFormEast] = useState(25);
  const [formWest, setFormWest] = useState(25);
  const [formError, setFormError] = useState('');

  // Filtering & Sorting
  const filtered = intersections
    .filter((item) => {
      const matchSearch =
        item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.locationArea.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchLevel = levelFilter === 'ALL' || item.congestionLevel === levelFilter;
      return matchSearch && matchLevel;
    })
    .sort((a, b) => {
      let comparison = 0;
      if (sortField === 'name') comparison = a.name.localeCompare(b.name);
      if (sortField === 'vehicles') comparison = a.totalVehicles - b.totalVehicles;
      if (sortField === 'density') comparison = a.densityPercentage - b.densityPercentage;
      if (sortField === 'wait') comparison = a.averageWaitTimeSec - b.averageWaitTimeSec;
      return sortAsc ? comparison : -comparison;
    });

  const handleOpenAdd = () => {
    setFormName('');
    setFormArea('');
    setFormNorth(20);
    setFormSouth(20);
    setFormEast(20);
    setFormWest(20);
    setFormError('');
    setIsAddModalOpen(true);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formArea.trim()) {
      setFormError('Please fill out all required name and area fields.');
      return;
    }
    addIntersection({
      name: formName.trim(),
      locationArea: formArea.trim(),
      directionalCounts: {
        NORTH: Number(formNorth),
        SOUTH: Number(formSouth),
        EAST: Number(formEast),
        WEST: Number(formWest),
      },
    });
    setIsAddModalOpen(false);
  };

  const handleOpenEdit = (item: Intersection) => {
    setEditingIntersection(item);
    setFormName(item.name);
    setFormArea(item.locationArea);
    setFormNorth(item.directionalCounts.NORTH);
    setFormSouth(item.directionalCounts.SOUTH);
    setFormEast(item.directionalCounts.EAST);
    setFormWest(item.directionalCounts.WEST);
    setFormError('');
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingIntersection) return;
    if (!formName.trim() || !formArea.trim()) {
      setFormError('Please fill out all required fields.');
      return;
    }

    const newCounts = {
      NORTH: Math.max(0, Number(formNorth)),
      SOUTH: Math.max(0, Number(formSouth)),
      EAST: Math.max(0, Number(formEast)),
      WEST: Math.max(0, Number(formWest)),
    };
    const total = newCounts.NORTH + newCounts.SOUTH + newCounts.EAST + newCounts.WEST;

    updateIntersection(editingIntersection.id, {
      name: formName.trim(),
      locationArea: formArea.trim(),
      directionalCounts: newCounts,
      totalVehicles: total,
    });
    setEditingIntersection(null);
  };

  const handleConfirmDelete = () => {
    if (deletingId) {
      deleteIntersection(deletingId);
      setDeletingId(null);
    }
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Intersection Management & Configuration
            <span className="text-xs font-mono font-normal text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
              {intersections.length} Active Nodes
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Configure junction geometry, directional vehicle queues, surveillance feed states, and cycle parameters.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/25 transition active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          Add Sample Intersection
        </button>
      </div>

      {/* Search, Filter & Sort Controls */}
      <div className="bg-[#131D31] p-4 rounded-2xl border border-slate-800/90 flex flex-wrap items-center justify-between gap-4">
        {/* Search */}
        <div className="relative flex-1 min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search by intersection name, corridor area, or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900/90 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-100 placeholder-slate-500 focus:outline-none focus:border-blue-500 transition"
          />
        </div>

        {/* Level Filters */}
        <div className="flex items-center gap-1.5 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
          {(['ALL', 'LOW', 'MODERATE', 'HIGH', 'CRITICAL'] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setLevelFilter(lvl)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                levelFilter === lvl
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lvl}
            </button>
          ))}
        </div>

        {/* Sort Buttons */}
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span className="text-[11px] font-mono">Sort by:</span>
          {(['vehicles', 'density', 'wait', 'name'] as const).map((field) => (
            <button
              key={field}
              onClick={() => {
                if (sortField === field) setSortAsc(!sortAsc);
                else {
                  setSortField(field);
                  setSortAsc(false);
                }
              }}
              className={`px-2.5 py-1 rounded-lg border text-xs capitalize font-medium flex items-center gap-1 transition ${
                sortField === field
                  ? 'bg-slate-800 text-white border-blue-500/40'
                  : 'border-slate-800 text-slate-400 hover:bg-slate-900'
              }`}
            >
              {field}
              {sortField === field && <ArrowUpDown className="w-3 h-3 text-blue-400" />}
            </button>
          ))}
        </div>
      </div>

      {/* Main Intersections Table */}
      <div className="bg-[#131D31] rounded-2xl border border-slate-800/90 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="text-[11px] uppercase font-mono text-slate-400 border-b border-slate-800 bg-slate-900/60">
              <tr>
                <th className="py-3 px-4">Node ID & Name</th>
                <th className="py-3 px-3">Vehicle Count</th>
                <th className="py-3 px-3">Density</th>
                <th className="py-3 px-3">Active Signal Phase</th>
                <th className="py-3 px-3">Avg Wait Time</th>
                <th className="py-3 px-3">Mode</th>
                <th className="py-3 px-3">Congestion Level</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {filtered.map((item) => (
                <tr key={item.id} className="hover:bg-slate-900/40 transition">
                  {/* Name & ID */}
                  <td className="py-3.5 px-4">
                    <div className="font-semibold text-slate-100 flex items-center gap-2">
                      {item.name}
                      <span className="text-[10px] font-mono text-blue-400 bg-blue-500/10 px-1.5 py-0.5 rounded border border-blue-500/20">
                        {item.id}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{item.locationArea}</div>
                  </td>

                  {/* Vehicle count */}
                  <td className="py-3.5 px-3 font-mono font-medium text-slate-200">
                    <div className="flex items-center gap-1.5">
                      <Car className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.totalVehicles}</span>
                    </div>
                  </td>

                  {/* Density */}
                  <td className="py-3.5 px-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full rounded-full ${
                            item.densityPercentage > 80
                              ? 'bg-rose-500'
                              : item.densityPercentage > 60
                              ? 'bg-amber-500'
                              : 'bg-emerald-500'
                          }`}
                          style={{ width: `${item.densityPercentage}%` }}
                        />
                      </div>
                      <span className="font-mono text-[11px] text-slate-300 font-semibold">
                        {item.densityPercentage}%
                      </span>
                    </div>
                  </td>

                  {/* Active Signal */}
                  <td className="py-3.5 px-3">
                    <span className="inline-flex items-center gap-1.5 font-mono text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      {item.signal.activeDirection} ({item.signal.timeRemainingSec}s)
                    </span>
                  </td>

                  {/* Wait Time */}
                  <td className="py-3.5 px-3 font-mono text-slate-300">
                    {item.averageWaitTimeSec}s
                  </td>

                  {/* Mode */}
                  <td className="py-3.5 px-3">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        item.signal.isManualOverride
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {item.signal.isManualOverride ? 'Manual Override' : 'Adaptive Auto'}
                    </span>
                  </td>

                  {/* Congestion Level */}
                  <td className="py-3.5 px-3">
                    <span
                      className={`px-2 py-0.5 rounded-full text-[11px] font-bold ${
                        item.congestionLevel === 'CRITICAL'
                          ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30 animate-pulse'
                          : item.congestionLevel === 'HIGH'
                          ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30'
                          : item.congestionLevel === 'MODERATE'
                          ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      }`}
                    >
                      {item.congestionLevel}
                    </span>
                  </td>

                  {/* Actions */}
                  <td className="py-3.5 px-4 text-right">
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        onClick={() => setViewingIntersection(item)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-blue-400 hover:bg-slate-800 transition"
                        title="View Detailed Telemetry & Directional Queues"
                      >
                        <Eye className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => handleOpenEdit(item)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-400 hover:bg-slate-800 transition"
                        title="Edit Intersection Details"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => addTrafficToIntersection(item.id, 20)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-amber-400 hover:bg-slate-800 transition"
                        title="Inject Simulated Traffic (+20)"
                      >
                        <TrendingUp className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => setDeletingId(item.id)}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-rose-400 hover:bg-slate-800 transition"
                        title="Delete Intersection"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detailed View Modal Drawer */}
      {viewingIntersection && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#131D31] border border-slate-800 rounded-2xl max-w-2xl w-full p-6 space-y-5 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-start justify-between border-b border-slate-800 pb-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
                    {viewingIntersection.id}
                  </span>
                  <h3 className="text-lg font-bold text-white">{viewingIntersection.name}</h3>
                </div>
                <p className="text-xs text-slate-400 mt-0.5">{viewingIntersection.locationArea}</p>
              </div>
              <button
                onClick={() => setViewingIntersection(null)}
                className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-3 gap-3">
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase font-mono text-slate-400">Total Queue Load</span>
                <div className="text-xl font-bold font-mono text-white mt-0.5">
                  {viewingIntersection.totalVehicles}
                </div>
              </div>
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase font-mono text-slate-400">Density Rating</span>
                <div className="text-xl font-bold font-mono text-amber-400 mt-0.5">
                  {viewingIntersection.densityPercentage}%
                </div>
              </div>
              <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                <span className="text-[10px] uppercase font-mono text-slate-400">Average Wait Time</span>
                <div className="text-xl font-bold font-mono text-cyan-400 mt-0.5">
                  {viewingIntersection.averageWaitTimeSec}s
                </div>
              </div>
            </div>

            {/* 4 Directions Queue */}
            <div className="space-y-2">
              <h4 className="text-xs font-semibold text-slate-300">Directional Vehicle Breakdown</h4>
              <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                {(['NORTH', 'SOUTH', 'EAST', 'WEST'] as const).map((dir) => (
                  <div key={dir} className="p-3 bg-slate-900/60 rounded-xl border border-slate-800 space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-slate-200">{dir} Approach</span>
                      <span className="text-blue-400 font-bold">{viewingIntersection.directionalCounts[dir]} vehicles</span>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Configured Green Duration: <strong>{viewingIntersection.signal.timings[dir]}s</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
              <button
                onClick={() => {
                  runOptimization(viewingIntersection.id);
                  setViewingIntersection(null);
                }}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition"
              >
                Run Adaptive Optimization
              </button>
              <button
                onClick={() => setViewingIntersection(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Intersection Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveAdd}
            className="bg-[#131D31] border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Add Sample Intersection</h3>
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/40 text-xs text-rose-200">
                {formError}
              </div>
            )}

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Intersection Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lajpat Nagar Ring Road Crossing"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Location Area Corridor *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. South Delhi Commercial Belt"
                  value={formArea}
                  onChange={(e) => setFormArea(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-2">
                <label className="block text-slate-300 font-medium mb-2">Initial Directional Vehicle Loads</label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400">North Queue:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={formNorth}
                      onChange={(e) => setFormNorth(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">South Queue:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={formSouth}
                      onChange={(e) => setFormSouth(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">East Queue:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={formEast}
                      onChange={(e) => setFormEast(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">West Queue:</span>
                    <input
                      type="number"
                      min="0"
                      max="100"
                      value={formWest}
                      onChange={(e) => setFormWest(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setIsAddModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white transition"
              >
                Create Intersection
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit Intersection Modal */}
      {editingIntersection && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <form
            onSubmit={handleSaveEdit}
            className="bg-[#131D31] border border-slate-800 rounded-2xl max-w-lg w-full p-6 space-y-4 animate-in fade-in zoom-in-95 duration-200"
          >
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white">Edit Intersection: {editingIntersection.id}</h3>
              <button
                type="button"
                onClick={() => setEditingIntersection(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-300 font-medium mb-1">Intersection Name</label>
                <input
                  type="text"
                  required
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-slate-300 font-medium mb-1">Corridor Area</label>
                <input
                  type="text"
                  required
                  value={formArea}
                  onChange={(e) => setFormArea(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div className="pt-2">
                <label className="block text-slate-300 font-medium mb-2">Adjust Directional Queues</label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-slate-400">North:</span>
                    <input
                      type="number"
                      min="0"
                      value={formNorth}
                      onChange={(e) => setFormNorth(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">South:</span>
                    <input
                      type="number"
                      min="0"
                      value={formSouth}
                      onChange={(e) => setFormSouth(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">East:</span>
                    <input
                      type="number"
                      min="0"
                      value={formEast}
                      onChange={(e) => setFormEast(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-slate-400">West:</span>
                    <input
                      type="number"
                      min="0"
                      value={formWest}
                      onChange={(e) => setFormWest(Number(e.target.value))}
                      className="w-full mt-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => setEditingIntersection(null)}
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingId && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#131D31] border border-rose-500/40 rounded-2xl max-w-sm w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-sm font-bold text-white">Confirm Node Deletion</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Are you sure you want to remove intersection <strong>{deletingId}</strong> from active telemetry? This removes its traffic counters and signal controller from the simulation grid.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setDeletingId(null)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
