/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        traffic: {
          bg: '#0B1120',       // Deep navy background
          card: '#131D31',     // Elevated card background
          border: '#1E293B',   // Subtle border
          input: '#1A243B',    // Input fields
          hover: '#1F2C4A',    // Hover states
          green: '#10B981',    // Low traffic / Green signal
          amber: '#F59E0B',    // Moderate traffic / Yellow signal
          red: '#EF4444',      // Heavy congestion / Red signal
          blue: '#3B82F6',     // Primary accent
          indigo: '#6366F1',   // Secondary accent
          purple: '#8B5CF6'    // Special highlight / Emergency
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
        mono: ['JetBrains Mono', 'Fira Code', 'monospace']
      }
    },
  },
  plugins: [],
}
