import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  Settings as SettingsIcon,
  RotateCcw,
  Save,
  CheckCircle,
  AlertTriangle,
  Sliders,
  Bell,
  Clock,
  ShieldCheck,
  Zap,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const {
    settings,
    updateSettings,
    resetSettingsToDefault,
    resetSimulation,
    showToast,
  } = useTraffic();

  // Local form state
  const [speed, setSpeed] = useState(settings.simulationSpeed);
  const [threshLow, setThreshLow] = useState(settings.thresholds.low);
  const [threshMod, setThreshMod] = useState(settings.thresholds.moderate);
  const [threshHigh, setThreshHigh] = useState(settings.thresholds.high);
  const [threshCrit, setThreshCrit] = useState(settings.thresholds.critical);
  const [maxCapacity, setMaxCapacity] = useState(settings.maxVehicleCapacityPerIntersection);
  const [waitAlertThreshold, setWaitAlertThreshold] = useState(settings.waitTimeAlertThresholdSec);
  const [minGreen, setMinGreen] = useState(settings.minGreenSec);
  const [maxGreen, setMaxGreen] = useState(settings.maxGreenSec);
  const [enableAudio, setEnableAudio] = useState(settings.enableAudioAlerts);
  const [enableAutoOpt, setEnableAutoOpt] = useState(settings.enableAutoOptimization);

  const [isResetConfirmOpen, setIsResetConfirmOpen] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (minGreen >= maxGreen) {
      showToast('Validation Error: Minimum green duration must be strictly less than maximum green duration.', 'warning');
      return;
    }
    if (threshLow >= threshMod || threshMod >= threshHigh) {
      showToast('Validation Error: Thresholds must be in strictly increasing order (Low < Moderate < High).', 'warning');
      return;
    }

    updateSettings({
      simulationSpeed: speed,
      thresholds: {
        low: threshLow,
        moderate: threshMod,
        high: threshHigh,
        critical: threshCrit,
      },
      maxVehicleCapacityPerIntersection: maxCapacity,
      waitTimeAlertThresholdSec: waitAlertThreshold,
      minGreenSec: minGreen,
      maxGreenSec: maxGreen,
      enableAudioAlerts: enableAudio,
      enableAutoOptimization: enableAutoOpt,
    });

    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleConfirmReset = () => {
    resetSettingsToDefault();
    resetSimulation();
    setSpeed(1);
    setThreshLow(30);
    setThreshMod(60);
    setThreshHigh(80);
    setThreshCrit(100);
    setMaxCapacity(220);
    setWaitAlertThreshold(65);
    setMinGreen(10);
    setMaxGreen(60);
    setEnableAudio(false);
    setEnableAutoOpt(false);
    setIsResetConfirmOpen(false);
  };

  return (
    <div className="p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            System & Simulation Settings
            <span className="text-xs font-mono font-normal text-slate-400 bg-slate-800/80 px-2 py-0.5 rounded">
              Config V1.0
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Calibrate adaptive signal timing parameters, congestion density cutoffs, and simulation clock speeds.
          </p>
        </div>

        <button
          onClick={() => setIsResetConfirmOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-rose-600/20 hover:bg-rose-600/30 text-rose-300 border border-rose-500/30 transition self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset All to Factory Defaults
        </button>
      </div>

      {savedSuccess && (
        <div className="p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          Settings persisted to localStorage and applied immediately to the active simulation engine.
        </div>
      )}

      {/* Main Settings Form */}
      <form onSubmit={handleSaveSettings} className="space-y-6">
        {/* Section 1: Simulation Engine Parameters */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Clock className="w-4 h-4 text-blue-400" />
            <h3 className="text-sm font-semibold text-white">Simulation Engine Execution Speed</h3>
          </div>

          <div className="space-y-3">
            <label className="block text-xs text-slate-300 font-medium">
              Simulation Clock Multiplier (Affects Countdown Rates & Telemetry Ticks)
            </label>
            <div className="grid grid-cols-4 gap-3">
              {[0.5, 1, 2, 5].map((s) => (
                <button
                  type="button"
                  key={s}
                  onClick={() => setSpeed(s)}
                  className={`py-3 rounded-xl border text-xs font-bold font-mono transition ${
                    speed === s
                      ? 'bg-blue-600 text-white border-blue-500 shadow-lg shadow-blue-600/25'
                      : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  {s}x Speed
                  <span className="block text-[10px] font-normal text-slate-300 mt-0.5">
                    {s === 1 ? 'Real-time (2s tick)' : `${Math.round(2000 / s)}ms tick`}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Section 2: Congestion Density Thresholds */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-semibold text-white">Congestion Density Thresholds (%)</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Low Traffic Floor (Green)</span>
                <span className="font-mono font-bold text-emerald-400">&le; {threshLow}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="45"
                value={threshLow}
                onChange={(e) => setThreshLow(Number(e.target.value))}
                className="w-full accent-emerald-500 bg-slate-800"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Moderate Congestion Ceiling (Amber)</span>
                <span className="font-mono font-bold text-amber-400">{threshLow + 1}% - {threshMod}%</span>
              </div>
              <input
                type="range"
                min="46"
                max="75"
                value={threshMod}
                onChange={(e) => setThreshMod(Number(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>High Congestion Trigger (Orange)</span>
                <span className="font-mono font-bold text-orange-400">{threshMod + 1}% - {threshHigh}%</span>
              </div>
              <input
                type="range"
                min="70"
                max="85"
                value={threshHigh}
                onChange={(e) => setThreshHigh(Number(e.target.value))}
                className="w-full accent-orange-500 bg-slate-800"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Critical Gridlock Threshold (Red)</span>
                <span className="font-mono font-bold text-rose-400">&gt; {threshHigh}%</span>
              </div>
              <input
                type="range"
                min="85"
                max="100"
                value={threshCrit}
                onChange={(e) => setThreshCrit(Number(e.target.value))}
                className="w-full accent-rose-500 bg-slate-800"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Adaptive Algorithm Durations & Capacity */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Zap className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-semibold text-white">Adaptive Signal Algorithm Limits</h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Minimum Green Phase Duration (Seconds)
              </label>
              <input
                type="number"
                min="5"
                max="25"
                value={minGreen}
                onChange={(e) => setMinGreen(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Pedestrian clearance safety minimum floor</span>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Maximum Green Phase Duration (Seconds)
              </label>
              <input
                type="number"
                min="40"
                max="120"
                value={maxGreen}
                onChange={(e) => setMaxGreen(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Maximum allowable single phase hold</span>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Max Node Vehicle Capacity (Vehicles)
              </label>
              <input
                type="number"
                min="100"
                max="500"
                value={maxCapacity}
                onChange={(e) => setMaxCapacity(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Used to compute 100% density saturation</span>
            </div>

            <div>
              <label className="block text-slate-300 font-medium mb-1">
                Queue Waiting Delay Alert Threshold (Seconds)
              </label>
              <input
                type="number"
                min="30"
                max="180"
                value={waitAlertThreshold}
                onChange={(e) => setWaitAlertThreshold(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-500 mt-1 block">Surpassing generates automatic incident alert</span>
            </div>
          </div>
        </div>

        {/* Section 4: Operational Toggles */}
        <div className="bg-[#131D31] border border-slate-800/90 rounded-2xl p-6 space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
            <Bell className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-white">System Automation & Notifications</h3>
          </div>

          <div className="space-y-3">
            <label className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-white block">Continuous Dynamic Optimization</span>
                <span className="text-[11px] text-slate-400">Automatically recalculates splits every 3 simulation cycles</span>
              </div>
              <input
                type="checkbox"
                checked={enableAutoOpt}
                onChange={(e) => setEnableAutoOpt(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 bg-slate-800 border-slate-700"
              />
            </label>

            <label className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800 cursor-pointer">
              <div>
                <span className="text-xs font-semibold text-white block">Audible High-Severity Alert Chimes</span>
                <span className="text-[11px] text-slate-400">Play synthetic tone when critical gridlock is detected</span>
              </div>
              <input
                type="checkbox"
                checked={enableAudio}
                onChange={(e) => setEnableAudio(e.target.checked)}
                className="w-4 h-4 rounded text-blue-600 focus:ring-blue-500 bg-slate-800 border-slate-700"
              />
            </label>
          </div>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="submit"
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/25 transition active:scale-95"
          >
            <Save className="w-4 h-4" />
            Save & Apply Configurations
          </button>
        </div>
      </form>

      {/* Reset Confirmation Dialog */}
      {isResetConfirmOpen && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#131D31] border border-rose-500/40 rounded-2xl max-w-sm w-full p-5 space-y-4 animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center gap-3 text-rose-400">
              <AlertTriangle className="w-6 h-6 shrink-0" />
              <h3 className="text-sm font-bold text-white">Confirm Factory Reset</h3>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This will restore all adaptive timing formulas, thresholds, and simulation queues to default initial values. All saved localStorage keys will be cleared.
            </p>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setIsResetConfirmOpen(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-300"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmReset}
                className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-600 hover:bg-rose-500 text-white"
              >
                Reset Everything
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
