import React, { useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import {
  BarChart,
  Bar,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import {
  Download,
  Printer,
  Calendar,
  Filter,
  BarChart3,
  TrendingDown,
  TrendingUp,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  Info,
} from 'lucide-react';
import { PrintableReportModal } from '../components/reports/PrintableReportModal';

export const AnalyticsPage: React.FC = () => {
  const { intersections, alerts, logs, vehicles } = useTraffic();

  const [timeFilter, setTimeFilter] = useState<'15m' | '1h' | '24h'>('1h');
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Chart 1: Vehicle Count by Intersection
  const vehicleCountData = intersections.map((item) => ({
    name: item.name.split('-')[0].trim(),
    vehicles: item.totalVehicles,
    density: item.densityPercentage,
  }));

  // Chart 2: Average Waiting Time by Intersection
  const waitTimeData = intersections.map((item) => ({
    name: item.name.split('-')[0].trim(),
    waitTime: item.averageWaitTimeSec,
  }));

  // Chart 3: Signal Timing Comparison across Directional Splits
  const signalTimingData = intersections.map((item) => ({
    name: item.id,
    North: item.signal.timings.NORTH,
    South: item.signal.timings.SOUTH,
    East: item.signal.timings.EAST,
    West: item.signal.timings.WEST,
  }));

  // Chart 4: Alerts by Severity
  const alertSeverityData = [
    { severity: 'Critical', count: alerts.filter((a) => a.severity === 'CRITICAL').length, color: '#EF4444' },
    { severity: 'High', count: alerts.filter((a) => a.severity === 'HIGH').length, color: '#F97316' },
    { severity: 'Medium', count: alerts.filter((a) => a.severity === 'MEDIUM').length, color: '#F59E0B' },
    { severity: 'Low', count: alerts.filter((a) => a.severity === 'LOW').length, color: '#3B82F6' },
  ];

  // Chart 5: Historical Trend Data from active history points
  const historyTrendData = (intersections[0]?.history || []).map((pt, idx) => {
    let totalVeh = 0;
    let avgWait = 0;
    intersections.forEach((i) => {
      const h = i.history[idx] || i.history[i.history.length - 1];
      if (h) {
        totalVeh += h.vehicleCount;
        avgWait += h.avgWaitSec;
      }
    });
    return {
      time: pt.timeStr,
      totalVehicles: totalVeh,
      avgWaitTime: Math.round(avgWait / (intersections.length || 1)),
    };
  });

  // Export CSV Functionality
  const handleExportCSV = () => {
    const headers = [
      'Intersection_ID',
      'Intersection_Name',
      'Corridor_Area',
      'Total_Vehicles',
      'Density_Percentage',
      'Congestion_Level',
      'Avg_Wait_Time_Sec',
      'Active_Signal_Phase',
      'Active_Signal_Color',
      'Remaining_Time_Sec',
      'North_Vehicles',
      'South_Vehicles',
      'East_Vehicles',
      'West_Vehicles',
      'North_Green_Sec',
      'South_Green_Sec',
      'East_Green_Sec',
      'West_Green_Sec',
      'Camera_Status',
    ];

    const rows = intersections.map((item) => [
      item.id,
      `"${item.name}"`,
      `"${item.locationArea}"`,
      item.totalVehicles,
      `${item.densityPercentage}%`,
      item.congestionLevel,
      item.averageWaitTimeSec,
      item.signal.activeDirection,
      item.signal.color,
      item.signal.timeRemainingSec,
      item.directionalCounts.NORTH,
      item.directionalCounts.SOUTH,
      item.directionalCounts.EAST,
      item.directionalCounts.WEST,
      item.signal.timings.NORTH,
      item.signal.timings.SOUTH,
      item.signal.timings.EAST,
      item.signal.timings.WEST,
      item.cameraStatus,
    ]);

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute(
      'download',
      `smart_traffic_delhi_telemetry_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
            Traffic Intelligence & Performance Analytics
            <span className="text-xs font-mono font-normal text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/20">
              Corridor Audit
            </span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Empirical efficiency charts: queue dissipations, adaptive split comparisons, delay trends, and incident histograms.
          </p>
        </div>

        {/* Action Buttons & Simulated Time Filter */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Time Filter */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            <span className="text-[10px] uppercase font-mono text-slate-500 px-2 font-bold">Window:</span>
            {(['15m', '1h', '24h'] as const).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeFilter(tf)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition ${
                  timeFilter === tf
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {tf === '15m' ? 'Last 15 Min' : tf === '1h' ? 'Last 1 Hour' : 'Last 24 Hours'} (Sim)
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-600/20 transition active:scale-95"
            title="Download CSV export with live simulation values"
          >
            <Download className="w-3.5 h-3.5" />
            Export Live CSV
          </button>

          <button
            onClick={() => setIsPrintModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5 text-blue-400" />
            Print Executive Report
          </button>
        </div>
      </div>

      {/* High-level Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 font-medium">Estimated Queue Delay Saved</span>
          <div className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {logs.reduce((acc, curr) => acc + curr.estimatedDelayReductionSec, 0) + 120}s
          </div>
          <span className="text-[11px] text-emerald-400/80 mt-0.5 block">Via dynamic adaptive splits</span>
        </div>

        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 font-medium">Estimated Fuel Saved (Simulated)</span>
          <div className="text-2xl font-bold font-mono text-cyan-400 mt-1">
            {(logs.reduce((acc, curr) => acc + curr.estimatedFuelSavedLiters, 0) + 18.5).toFixed(1)} Liters
          </div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">Reduced idling emission baseline</span>
        </div>

        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 font-medium">Network Green Wave Compliance</span>
          <div className="text-2xl font-bold font-mono text-blue-400 mt-1">98.2%</div>
          <span className="text-[11px] text-blue-400/80 mt-0.5 block">No opposing phase lockouts</span>
        </div>

        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-4">
          <span className="text-xs text-slate-400 font-medium">Surveillance Uptime</span>
          <div className="text-2xl font-bold font-mono text-white mt-1">99.9%</div>
          <span className="text-[11px] text-slate-400 mt-0.5 block">All 8 sensor nodes reporting</span>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Chart 1: Vehicle Count by Intersection */}
        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Vehicular Volume per Node</h3>
            <p className="text-xs text-slate-400">Total detected vehicles waiting across all four approaches</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={vehicleCountData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="name" stroke="#64748B" fontSize={10} angle={-25} textAnchor="end" />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="vehicles" name="Vehicles" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Average Waiting Time by Intersection */}
        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Average Queue Waiting Duration (Seconds)</h3>
            <p className="text-xs text-slate-400">Target threshold is under 45 seconds for smooth corridor flow</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={waitTimeData} margin={{ top: 10, right: 10, left: -20, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="name" stroke="#64748B" fontSize={10} angle={-25} textAnchor="end" />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="waitTime" name="Wait Time (s)" fill="#F59E0B" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Signal Timing Split Allocation */}
        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Directional Green Duration Allocations (Seconds)</h3>
            <p className="text-xs text-slate-400">Adaptive split comparison across North, South, East, and West</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={signalTimingData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="name" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="North" stackId="a" fill="#3B82F6" />
                <Bar dataKey="South" stackId="a" fill="#10B981" />
                <Bar dataKey="East" stackId="a" fill="#F59E0B" />
                <Bar dataKey="West" stackId="a" fill="#8B5CF6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Alerts by Severity */}
        <div className="bg-[#131D31] border border-slate-800 rounded-2xl p-5 space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-white">Incident Alerts Breakdown by Severity</h3>
            <p className="text-xs text-slate-400">Total volume of threshold breaches logged</p>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={alertSeverityData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1E293B" />
                <XAxis dataKey="severity" stroke="#64748B" fontSize={11} />
                <YAxis stroke="#64748B" fontSize={11} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0F172A',
                    borderColor: '#334155',
                    borderRadius: '0.75rem',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" name="Alert Count">
                  {alertSeverityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Printable Report Modal */}
      {isPrintModalOpen && (
        <PrintableReportModal onClose={() => setIsPrintModalOpen(false)} />
      )}
    </div>
  );
};
