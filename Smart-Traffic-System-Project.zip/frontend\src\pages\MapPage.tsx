import React, { useEffect, useRef, useState } from 'react';
import { useTraffic } from '../context/TrafficContext';
import L from 'leaflet';
import {
  MapPin,
  Layers,
  RotateCcw,
  Zap,
  Car,
  TrendingUp,
  AlertTriangle,
  ArrowRight,
  ShieldAlert,
  Info,
} from 'lucide-react';
import { CongestionLevel, Intersection } from '../types/traffic';

export const MapPage: React.FC = () => {
  const {
    intersections,
    selectedIntersectionId,
    setSelectedIntersectionId,
    runOptimization,
    addTrafficToIntersection,
    setActiveTab,
    emergencyProposal,
  } = useTraffic();

  const [filterLevel, setFilterLevel] = useState<'ALL' | CongestionLevel>('ALL');
  const [mapMode, setMapMode] = useState<'LEAFLET' | 'SCHEMATIC'>('LEAFLET');
  const [tileError, setTileError] = useState(false);

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const leafletMapRef = useRef<L.Map | null>(null);
  const markersRef = useRef<{ [key: string]: L.Marker }>({});

  const DELHI_CENTER: [number, number] = [28.6139, 77.2090]; // New Delhi Center

  const filteredIntersections = intersections.filter((item) => {
    if (filterLevel === 'ALL') return true;
    if (filterLevel === 'HIGH' || filterLevel === 'CRITICAL') {
      return item.congestionLevel === 'HIGH' || item.congestionLevel === 'CRITICAL';
    }
    return item.congestionLevel === filterLevel;
  });

  const selectedIntersection = intersections.find((i) => i.id === selectedIntersectionId) || intersections[0];

  // Helper to get marker color
  const getMarkerColor = (level: CongestionLevel) => {
    switch (level) {
      case 'LOW':
        return '#10B981'; // Green
      case 'MODERATE':
        return '#F59E0B'; // Amber
      case 'HIGH':
      case 'CRITICAL':
        return '#EF4444'; // Red
    }
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (mapMode !== 'LEAFLET' || !mapContainerRef.current) return;

    if (!leafletMapRef.current) {
      const map = L.map(mapContainerRef.current, {
        center: DELHI_CENTER,
        zoom: 12,
        zoomControl: false,
      });

      L.control.zoom({ position: 'topright' }).addTo(map);

      // OpenStreetMap Tile Layer (with dark mode filter in CSS)
      const tileLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
        maxZoom: 18,
      });

      tileLayer.on('tileerror', () => {
        setTileError(true);
      });

      tileLayer.addTo(map);
      leafletMapRef.current = map;
    }

    return () => {
      // Cleanup on unmount
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [mapMode]);

  // Update Markers dynamically when intersection state changes
  useEffect(() => {
    if (!leafletMapRef.current) return;
    const map = leafletMapRef.current;

    // Clear existing markers
    Object.values(markersRef.current).forEach((marker) => marker.remove());
    markersRef.current = {};

    filteredIntersections.forEach((item) => {
      const color = getMarkerColor(item.congestionLevel);
      const isSelected = item.id === selectedIntersectionId;
      const isEmergencyTarget = emergencyProposal?.targetIntersectionId === item.id;

      // Custom HTML Pin icon
      const customIcon = L.divIcon({
        className: 'custom-traffic-marker',
        html: `
          <div style="
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            width: ${isSelected || isEmergencyTarget ? '38px' : '30px'};
            height: ${isSelected || isEmergencyTarget ? '38px' : '30px'};
            border-radius: 50%;
            background: ${color};
            color: white;
            font-weight: bold;
            font-family: monospace;
            font-size: 11px;
            box-shadow: 0 0 ${isSelected || isEmergencyTarget ? '16px' : '8px'} ${color};
            border: 2px solid white;
            cursor: pointer;
            transition: all 0.2s ease;
          ">
            ${isEmergencyTarget ? '🚨' : item.totalVehicles}
            ${item.congestionLevel === 'CRITICAL' ? '<span style="position: absolute; top: -3px; right: -3px; width: 10px; height: 10px; background: red; border-radius: 50%; border: 1px solid white; animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite;"></span>' : ''}
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

      const marker = L.marker(item.coordinates, { icon: customIcon }).addTo(map);

      // Popup Content
      marker.bindPopup(`
        <div style="color: #0f172a; font-family: sans-serif; min-width: 180px;">
          <strong style="font-size: 13px; display: block; margin-bottom: 2px;">${item.name}</strong>
          <span style="font-size: 11px; color: #64748b; font-family: monospace;">${item.id}</span>
          <hr style="border: 0; border-top: 1px solid #e2e8f0; margin: 6px 0;" />
          <div style="font-size: 11px; line-height: 1.5;">
            <div>Vehicles: <b>${item.totalVehicles}</b> (${item.densityPercentage}% Density)</div>
            <div>Queue Wait: <b>${item.averageWaitTimeSec}s</b></div>
            <div>Phase: <b style="color: #059669;">${item.signal.activeDirection} (${item.signal.timeRemainingSec}s)</b></div>
            <div>Status: <span style="font-weight: 700; color: ${color};">${item.congestionLevel}</span></div>
          </div>
        </div>
      `);

      marker.on('click', () => {
        setSelectedIntersectionId(item.id);
      });

      markersRef.current[item.id] = marker;
    });
  }, [filteredIntersections, selectedIntersectionId, emergencyProposal]);

  const resetMapView = () => {
    if (leafletMapRef.current) {
      leafletMapRef.current.setView(DELHI_CENTER, 12, { animate: true });
    }
  };

  return (
    <div className="p-6 space-y-4 max-w-7xl mx-auto h-[calc(100vh-5rem)] flex flex-col">
      {/* Top Map Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#131D31] p-3.5 rounded-2xl border border-slate-800 shrink-0">
        <div className="flex items-center gap-2">
          <MapPin className="w-5 h-5 text-blue-400" />
          <div>
            <h2 className="text-sm font-bold text-white leading-none">
              Live Geographic Traffic Map
            </h2>
            <p className="text-[11px] text-slate-400 font-mono mt-0.5">
              Delhi NCR Metropolitan Surveillance Grid (8 Monitored Intersections)
            </p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex items-center gap-1.5 bg-slate-900/80 p-1 rounded-xl border border-slate-800 text-xs">
          {(['ALL', 'LOW', 'MODERATE', 'HIGH'] as const).map((lvl) => (
            <button
              key={lvl}
              onClick={() => setFilterLevel(lvl)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                filterLevel === lvl
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {lvl === 'ALL' ? 'All (8)' : lvl === 'HIGH' ? 'Congested / Red' : lvl}
            </button>
          ))}
        </div>

        {/* View Controls & Reset */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setMapMode(mapMode === 'LEAFLET' ? 'SCHEMATIC' : 'LEAFLET')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Toggle between OpenStreetMap tiles and Delhi NCR corridor schematic"
          >
            <Layers className="w-3.5 h-3.5 text-indigo-400" />
            {mapMode === 'LEAFLET' ? 'Schematic Mode' : 'Tile Map Mode'}
          </button>

          <button
            onClick={resetMapView}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
            title="Recenter Map on Delhi NCR"
          >
            <RotateCcw className="w-3.5 h-3.5 text-blue-400" />
            Recenter
          </button>
        </div>
      </div>

      {/* Main Map + Inspection Card Row */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-3 gap-4 min-h-0">
        {/* Map Viewport (2 cols) */}
        <div className="lg:col-span-2 bg-[#131D31] rounded-2xl border border-slate-800 overflow-hidden relative flex flex-col">
          {mapMode === 'LEAFLET' ? (
            <div
              ref={mapContainerRef}
              className="w-full h-full min-h-[480px] z-10"
              style={{ background: '#0b1120' }}
            />
          ) : (
            /* Fallback & Presentation Schematic Grid of Delhi NCR */
            <div className="w-full h-full min-h-[480px] p-6 flex flex-col justify-between bg-gradient-to-b from-[#0F172A] to-[#0B1120] overflow-y-auto">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-mono uppercase font-bold text-blue-400">
                  Delhi NCR Schematic Grid Topology
                </span>
                <span>Corridor Linkages & Node Density</span>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 my-auto py-4">
                {filteredIntersections.map((item) => {
                  const color = getMarkerColor(item.congestionLevel);
                  const isSelected = item.id === selectedIntersectionId;

                  return (
                    <div
                      key={item.id}
                      onClick={() => setSelectedIntersectionId(item.id)}
                      className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                        isSelected
                          ? 'border-blue-500 bg-blue-950/40 shadow-lg shadow-blue-500/20'
                          : 'border-slate-800 bg-slate-900/70 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400">{item.id}</span>
                        <span
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: color, boxShadow: `0 0 8px ${color}` }}
                        />
                      </div>
                      <div className="text-xs font-semibold text-white mt-1 line-clamp-1">{item.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">{item.locationArea}</div>
                      <div className="mt-3 flex items-center justify-between text-[11px] font-mono">
                        <span className="text-slate-300">Vehicles: {item.totalVehicles}</span>
                        <span style={{ color }}>{item.densityPercentage}%</span>
                      </div>
                    </div>
                  );
                })}
              </div>

              <div className="text-[11px] text-slate-500 font-mono text-center pt-2 border-t border-slate-800">
                Schematic mode preserves full classroom demonstration even without external tile server access.
              </div>
            </div>
          )}

          {/* Map Overlay: Legend */}
          <div className="absolute bottom-4 left-4 z-20 bg-[#0F172A]/90 backdrop-blur-md p-3 rounded-xl border border-slate-800 text-xs space-y-1.5 shadow-xl pointer-events-auto">
            <div className="text-[10px] uppercase font-mono font-bold text-slate-400">
              Traffic Density Legend
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500" />
              <span className="text-slate-300">0 - 30% (Low / Smooth)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-amber-500 shadow-sm shadow-amber-500" />
              <span className="text-slate-300">31 - 60% (Moderate Queue)</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500 shadow-sm shadow-red-500" />
              <span className="text-slate-300">61 - 100% (High / Critical Gridlock)</span>
            </div>
          </div>

          {/* Simulated Disclaimer watermark */}
          <div className="absolute top-4 left-4 z-20 bg-slate-900/80 backdrop-blur px-2.5 py-1 rounded-md border border-slate-800 text-[10px] font-mono text-slate-400">
            Simulated Sensor Nodes &bull; Delhi NCR
          </div>
        </div>

        {/* Inspection Sidebar (1 col) */}
        <div className="bg-[#131D31] rounded-2xl border border-slate-800 p-5 flex flex-col justify-between overflow-y-auto">
          {selectedIntersection ? (
            <div className="space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-blue-400 font-bold">
                    {selectedIntersection.id}
                  </span>
                  <span
                    className="px-2 py-0.5 rounded-full text-[11px] font-bold"
                    style={{
                      backgroundColor: `${getMarkerColor(selectedIntersection.congestionLevel)}20`,
                      color: getMarkerColor(selectedIntersection.congestionLevel),
                      border: `1px solid ${getMarkerColor(selectedIntersection.congestionLevel)}50`,
                    }}
                  >
                    {selectedIntersection.congestionLevel} CONGESTION
                  </span>
                </div>
                <h3 className="text-base font-bold text-white mt-1">
                  {selectedIntersection.name}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {selectedIntersection.locationArea}
                </p>
                <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                  Coords: {selectedIntersection.coordinates[0].toFixed(4)}° N, {selectedIntersection.coordinates[1].toFixed(4)}° E
                </div>
              </div>

              {/* Metrics Grid */}
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  <div className="text-[10px] font-mono uppercase text-slate-400">Vehicles In Queue</div>
                  <div className="text-xl font-bold font-mono text-white mt-0.5">
                    {selectedIntersection.totalVehicles}
                  </div>
                </div>

                <div className="bg-slate-900/80 p-3 rounded-xl border border-slate-800">
                  <div className="text-[10px] font-mono uppercase text-slate-400">Average Delay</div>
                  <div className="text-xl font-bold font-mono text-cyan-400 mt-0.5">
                    {selectedIntersection.averageWaitTimeSec}s
                  </div>
                </div>
              </div>

              {/* Directional Queue Telemetry */}
              <div className="space-y-2">
                <div className="text-xs font-semibold text-slate-300">Directional Vehicle Backlog</div>
                <div className="space-y-1.5 font-mono text-xs">
                  {(['NORTH', 'SOUTH', 'EAST', 'WEST'] as const).map((dir) => {
                    const count = selectedIntersection.directionalCounts[dir];
                    const isDirGreen =
                      selectedIntersection.signal.activeDirection === dir &&
                      selectedIntersection.signal.color === 'GREEN';

                    return (
                      <div
                        key={dir}
                        className={`flex items-center justify-between p-2 rounded-lg border ${
                          isDirGreen
                            ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                            : 'bg-slate-900/50 border-slate-800 text-slate-300'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              isDirGreen ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
                            }`}
                          />
                          <span className="font-bold">{dir}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <span className="text-slate-400 text-[11px]">
                            {selectedIntersection.signal.timings[dir]}s green
                          </span>
                          <span className="font-bold text-white">{count} veh</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Signal Controls */}
              <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-slate-300">Signal Status</span>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {selectedIntersection.signal.activeDirection} - {selectedIntersection.signal.color}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400">
                  Time Remaining in Current Phase: <strong className="text-white font-mono">{selectedIntersection.signal.timeRemainingSec}s</strong>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-2 pt-2">
                <button
                  onClick={() => runOptimization(selectedIntersection.id)}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-xs font-semibold bg-blue-600 hover:bg-blue-500 text-white shadow-lg shadow-blue-600/25 transition active:scale-95"
                >
                  <Zap className="w-3.5 h-3.5" />
                  Run Adaptive Optimization
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => addTrafficToIntersection(selectedIntersection.id, 25)}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                  >
                    <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
                    +Inject (+25)
                  </button>

                  <button
                    onClick={() => {
                      setActiveTab('signals');
                    }}
                    className="flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition"
                  >
                    Signals Panel <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex items-center justify-center text-slate-500 text-xs">
              Select an intersection pin on the map to inspect telemetry.
            </div>
          )}

          <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-slate-500">
            OpenStreetMap live tiles with offline SVG schematic fallback.
          </div>
        </div>
      </div>
    </div>
  );
};
