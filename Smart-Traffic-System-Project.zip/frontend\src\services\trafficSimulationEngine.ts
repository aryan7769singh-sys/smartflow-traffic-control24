import {
  Intersection,
  TrafficAlert,
  Vehicle,
  SystemSettings,
  CongestionLevel,
  Direction,
  ActivityItem,
} from '../types/traffic';
import { getNextDirection } from './adaptiveSignalService';

// Keep track of recent alert generation timestamps to prevent duplicates/spam
const alertCooldowns: Record<string, number> = {};

export function classifyCongestion(density: number, thresholds: SystemSettings['thresholds']): CongestionLevel {
  if (density >= thresholds.high) {
    return density >= thresholds.critical ? 'CRITICAL' : 'HIGH';
  }
  if (density >= thresholds.low + 1) {
    return 'MODERATE';
  }
  return 'LOW';
}

/**
 * Advances the simulation by 1 tick (deltaSeconds)
 */
export function simulateTick(
  intersections: Intersection[],
  alerts: TrafficAlert[],
  vehicles: Vehicle[],
  settings: SystemSettings,
  deltaSec: number
): {
  updatedIntersections: Intersection[];
  updatedAlerts: TrafficAlert[];
  updatedVehicles: Vehicle[];
  newActivities: ActivityItem[];
} {
  const newActivities: ActivityItem[] = [];
  const createdAlerts: TrafficAlert[] = [];
  const now = new Date();
  const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  // 1. Update Intersections
  const updatedIntersections = intersections.map((intersection) => {
    const updated = { ...intersection };
    const counts = { ...updated.directionalCounts };
    const signal = { ...updated.signal };

    // --- Signal Cycle Update ---
    if (!signal.isManualOverride) {
      let remaining = signal.timeRemainingSec - deltaSec;

      if (signal.color === 'GREEN' && remaining <= signal.yellowDurationSec) {
        signal.color = 'YELLOW';
      }

      if (remaining <= 0) {
        // Transition to next direction
        const nextDir = getNextDirection(signal.activeDirection);
        signal.activeDirection = nextDir;
        signal.color = 'GREEN';
        signal.timeRemainingSec = signal.timings[nextDir] || 30;
      } else {
        signal.timeRemainingSec = Math.max(0, Math.round(remaining));
      }
    }

    // --- Vehicle Inflow & Outflow Dynamics ---
    const activeDir = signal.activeDirection;
    const isGreen = signal.color === 'GREEN';

    const directions: Direction[] = ['NORTH', 'SOUTH', 'EAST', 'WEST'];

    directions.forEach((dir) => {
      // Outflow during Green phase
      if (isGreen && dir === activeDir) {
        const dischargeRate = Math.floor(Math.random() * 3) + 1; // 1-3 vehicles cleared per tick
        counts[dir] = Math.max(0, counts[dir] - dischargeRate);
      }

      // Natural stochastic inflow (simulated arriving traffic)
      // Slight bias based on time / intersection
      const inflowChance = Math.random();
      if (inflowChance > 0.45) {
        const arrivals = Math.floor(Math.random() * 2) + 1;
        counts[dir] += arrivals;
      }
    });

    const totalVehicles = counts.NORTH + counts.SOUTH + counts.EAST + counts.WEST;
    const capacity = settings.maxVehicleCapacityPerIntersection || 200;
    const rawDensity = Math.round((totalVehicles / capacity) * 100);
    const densityPercentage = Math.min(100, Math.max(5, rawDensity));

    const congestionLevel = classifyCongestion(densityPercentage, settings.thresholds);

    // Waiting time calculation: based on current queue and cycle
    const queueFactor = Math.round((totalVehicles / 4) * 1.3);
    const averageWaitTimeSec = Math.max(12, Math.min(120, queueFactor + (congestionLevel === 'CRITICAL' ? 30 : 0)));

    // Append to rolling history every few ticks
    const history = [...updated.history];
    if (Math.random() > 0.6 || history.length < 5) {
      history.push({
        timeStr: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        vehicleCount: totalVehicles,
        density: densityPercentage,
        avgWaitSec: averageWaitTimeSec,
      });
      if (history.length > 20) {
        history.shift(); // keep last 20 samples
      }
    }

    // --- Alert Generation Rules with Cooldown (40 seconds per alert type) ---
    const cooldownKeyHigh = `${intersection.id}-HIGH`;
    const lastAlertTimeHigh = alertCooldowns[cooldownKeyHigh] || 0;
    const nowMs = Date.now();

    if ((congestionLevel === 'CRITICAL' || congestionLevel === 'HIGH') && nowMs - lastAlertTimeHigh > 40000) {
      alertCooldowns[cooldownKeyHigh] = nowMs;
      const isCritical = congestionLevel === 'CRITICAL';
      const alert: TrafficAlert = {
        id: `ALT-${nowMs}-${Math.floor(Math.random() * 1000)}`,
        intersectionId: intersection.id,
        intersectionName: intersection.name,
        type: 'CONGESTION',
        severity: isCritical ? 'CRITICAL' : 'HIGH',
        description: `${isCritical ? 'Critical gridlock warning' : 'High density alert'}: ${intersection.name} reached ${densityPercentage}% density (${totalVehicles} vehicles in queue).`,
        timestamp: timeStr,
        status: 'ACTIVE',
      };
      createdAlerts.push(alert);
      newActivities.push({
        id: `ACT-${nowMs}-1`,
        timestamp: timeStr,
        type: 'ALERT',
        message: `Alert triggered for ${intersection.name}: ${congestionLevel} Congestion (${densityPercentage}%)`,
        level: isCritical ? 'alert' : 'warning',
      });
    }

    const cooldownKeyWait = `${intersection.id}-WAIT`;
    const lastAlertTimeWait = alertCooldowns[cooldownKeyWait] || 0;
    if (averageWaitTimeSec > settings.waitTimeAlertThresholdSec && nowMs - lastAlertTimeWait > 45000) {
      alertCooldowns[cooldownKeyWait] = nowMs;
      const alert: TrafficAlert = {
        id: `ALT-${nowMs}-${Math.floor(Math.random() * 1000)}`,
        intersectionId: intersection.id,
        intersectionName: intersection.name,
        type: 'WAIT_EXCEEDED',
        severity: averageWaitTimeSec > 80 ? 'CRITICAL' : 'HIGH',
        description: `Average queue wait duration surpassed threshold at ${averageWaitTimeSec}s at ${intersection.name}. Adaptive timing reallocation advised.`,
        timestamp: timeStr,
        status: 'ACTIVE',
      };
      createdAlerts.push(alert);
      newActivities.push({
        id: `ACT-${nowMs}-2`,
        timestamp: timeStr,
        type: 'ALERT',
        message: `Queue wait time exceeded limit at ${intersection.name} (${averageWaitTimeSec}s)`,
        level: 'warning',
      });
    }

    return {
      ...updated,
      directionalCounts: counts,
      totalVehicles,
      densityPercentage,
      congestionLevel,
      averageWaitTimeSec,
      signal,
      history,
    };
  });

  // 2. Update Simulated Vehicles
  const updatedVehicles = vehicles.map((v) => {
    let nextSec = v.estimatedArrivalSec - deltaSec;
    let nextStatus = v.status;

    if (nextSec <= 0) {
      if (v.status === 'Approaching') {
        nextStatus = 'Waiting';
        nextSec = Math.floor(Math.random() * 15) + 5;
      } else if (v.status === 'Waiting') {
        nextStatus = 'Passed';
        nextSec = 0;
      } else {
        // Reset vehicle to approach another intersection in simulation
        const randomInt = updatedIntersections[Math.floor(Math.random() * updatedIntersections.length)];
        return {
          ...v,
          intersectionId: randomInt.id,
          intersectionName: randomInt.name,
          estimatedArrivalSec: Math.floor(Math.random() * 30) + 10,
          status: 'Approaching' as const,
        };
      }
    }

    return {
      ...v,
      estimatedArrivalSec: Math.max(0, Math.round(nextSec)),
      status: nextStatus,
    };
  });

  // Merge alerts with deduplication limit
  const updatedAlerts = [...createdAlerts, ...alerts].slice(0, 50);

  return {
    updatedIntersections,
    updatedAlerts,
    updatedVehicles,
    newActivities,
  };
}
